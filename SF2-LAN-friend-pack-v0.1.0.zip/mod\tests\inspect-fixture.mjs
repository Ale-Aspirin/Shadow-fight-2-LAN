#!/usr/bin/env node
/* Fixture inspector: decodes mod/tests/fixtures/SF2User.b64 and prints the schema.
   Usage: node mod/tests/inspect-fixture.mjs [--xml] */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import * as C from '../overlay/sf2codec.mjs';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const fx = path.join(HERE, 'fixtures');
const raw = fs.readFileSync(path.join(fx, 'SF2User.b64'), 'utf8').trim();
console.log('blob bytes:', raw.length);

let xml;
try { xml = C.decodeUsers(raw); } catch (e) { console.error('DECODE FAILED:', e.message); process.exit(1); }
console.log('xml chars:', xml.length);

const tree = C.parseXml(xml);
const rootKids = tree.children.map((c) => c.name);
console.log('root children:', rootKids.join(', '));

function describe(n, depth, max) {
  for (const c of n.children.slice(0, max)) {
    const keys = Object.keys(c.attrs);
    console.log('  '.repeat(depth) + '<' + c.name + '> kids=' + c.children.length +
      ' attrs[' + keys.length + ']=' + keys.slice(0, 8).join(',') +
      (keys.length > 8 ? '...' : '') +
      (c.text && c.text.trim() ? ' text="' + c.text.trim().slice(0, 60) + '"' : ''));
    if (depth < 2) describe(c, depth + 1, 6);
  }
}
describe(tree, 1, 12);

const packsPath = path.join(fx, 'SF2Packs.xml');
if (fs.existsSync(packsPath)) {
  const px = fs.readFileSync(packsPath, 'utf8');
  console.log('\n--- SF2Packs.xml (' + px.length + ' B) ---\n' + px.slice(0, 3000));
}

if (process.argv.includes('--xml')) console.log('\n--- users XML head ---\n' + xml.slice(0, 4000));

const card = C.extractFighter(xml);
console.log('\n--- extractFighter() ---\n' + JSON.stringify(card, null, 1).slice(0, 2500));
const spans = C.warriorSpans(xml);
console.log('warriorSpans:', spans.length, spans.map((s) => JSON.stringify(s.attrs).slice(0, 160)).join('\n  '));
