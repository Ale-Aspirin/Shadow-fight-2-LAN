#!/usr/bin/env node
/* ============================================================================
 * SF2 LAN Duel Room - boot smoke test (zero npm deps; uses Node's global WebSocket)
 *
 *   node mod\tools\smoke.mjs            -> launch game, verify standalone boot
 *   node mod\tools\smoke.mjs --dump     -> also dump storage keys + save sizes
 * ==========================================================================*/
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import http from 'node:http';
import { fileURLToPath } from 'node:url';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(HERE, '..', '..');
const PORT = 8788, DEBUG_PORT = 9333;
const DUMP = process.argv.includes('--dump');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const get = (url) => new Promise((res, rej) => {
  http.get(url, (r) => { let d = ''; r.on('data', (c) => (d += c)); r.on('end', () => res(d)); }).on('error', rej);
});

function findBrowser() {
  return [
    'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
    'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe',
    'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe'
  ].find((p) => fs.existsSync(p));
}

class CDP {
  constructor(wsUrl) { this.ws = new WebSocket(wsUrl); this.id = 0; this.pending = new Map(); this.events = []; }
  ready() {
    return new Promise((res, rej) => {
      this.ws.onopen = () => res();
      this.ws.onerror = () => rej(new Error('cdp ws error'));
      this.ws.onmessage = (m) => {
        const msg = JSON.parse(m.data);
        if (msg.id && this.pending.has(msg.id)) { this.pending.get(msg.id)(msg); this.pending.delete(msg.id); }
        else if (msg.method) this.events.push(msg);
      };
    });
  }
  send(method, params = {}) {
    const id = ++this.id;
    return new Promise((res) => { this.pending.set(id, res); this.ws.send(JSON.stringify({ id, method, params })); });
  }
  async eval(expr) {
    const r = await Promise.race([
      this.send('Runtime.evaluate', { expression: expr, returnByValue: true, awaitPromise: true }),
      sleep(9000).then(() => ({ __timeout: true }))
    ]);
    if (r.__timeout) return 'TIMEOUT';
    if (r.result && r.result.exceptionDetails) return 'ERR: ' + r.result.exceptionDetails.text;
    return r.result && r.result.result ? r.result.result.value : undefined;
  }
}

(async () => {
  const browser = findBrowser();
  if (!browser) { console.error('[smoke] no Edge/Chrome found'); process.exit(2); }
  const profile = path.join(ROOT, 'profile', 'smoke-' + Date.now().toString(36));
  fs.mkdirSync(profile, { recursive: true });

  console.log('[smoke] starting relay + static server...');
  const srv = spawn(process.execPath, [path.join(ROOT, 'mod', 'server', 'lan-server.mjs'), '--quiet'],
    { cwd: ROOT, stdio: 'ignore' });
  await sleep(1500);

  console.log('[smoke] launching', path.basename(browser) + ' (a game window will appear)');
  const proc = spawn(browser, [
    '--app=http://127.0.0.1:' + PORT + '/index.html',
    '--user-data-dir=' + profile,
    '--remote-debugging-port=' + DEBUG_PORT,
    '--no-first-run', '--no-default-browser-check', '--disable-sync',
    '--window-size=1100,700', '--window-position=40,40'
  ], { stdio: 'ignore' });

  let targets = [];
  for (let i = 0; i < 40; i++) {
    await sleep(500);
    try { targets = JSON.parse(await get('http://127.0.0.1:' + DEBUG_PORT + '/json/list')); } catch { targets = []; }
    if (targets.some((t) => t.type === 'page' && t.url.includes('index.html'))) break;
  }
  const page = targets.find((t) => t.type === 'page' && t.url.includes('index.html'));
  if (!page) { console.error('[smoke] FAIL: page never appeared'); try { proc.kill(); srv.kill(); } catch {} process.exit(1); }

  const cdp = new CDP(page.webSocketDebuggerUrl);
  await cdp.ready();
  await cdp.send('Runtime.enable');
  await cdp.send('Log.enable');
  console.log('[smoke] attached, waiting 12 s for boot...');
  await sleep(12000);
  const checks = {};
  checks.url = await cdp.eval('location.href');
  checks.overlayLoaded = await cdp.eval('!!window.__SF2LAN');
  checks.gameInterface = await cdp.eval('typeof window.GameInterface');
  checks.standaloneForced = await cdp.eval('!!(window.GameInterface && window.GameInterface.hasFeature && window.GameInterface.hasFeature("standalone"))');
  checks.canvases = await cdp.eval('document.getElementsByTagName("canvas").length');
  checks.frames = await cdp.eval('window.__SF2LAN ? window.__SF2LAN.ticks : 0');
  checks.lobbyUILoaded = await cdp.eval('!!document.getElementById("sl-fab")');
  checks.importError = await cdp.eval('(window.__SF2LAN && window.__SF2LAN.importError) || "none"');
  const consoleTail = cdp.events
    .filter((e) => e.method === 'Runtime.consoleAPICalled')
    .map((e) => (e.params.args || []).map((a) => String(a.value != null ? a.value : (a.description || a.type))).join(' '))
    .slice(-14);
  checks.consoleTail = consoleTail.length ? '\n    ' + consoleTail.join('\n    ') : 'none';
  checks.storageCalls = await cdp.eval('JSON.stringify((window.__SF2LAN&&window.__SF2LAN.storageLog||[]).slice(0,5).map(function(e){return e.op+":"+e.key}))');
  if (DUMP) {
    checks.storageKeys = await cdp.eval('JSON.stringify(Object.keys(localStorage).map(function(k){return k+"("+String(localStorage.getItem(k)||"").length+")"}))');
    checks.jsStorageKeys = await cdp.eval('JSON.stringify(Object.keys(window.GameInterface.storage||{}))');
    const blob = await cdp.eval('(function(){try{var v=window.GameInterface.storage.getItem("SF2User");return v?String(v).length:0}catch(e){return "err:"+e.message}})()');
    checks.SF2UserLen = blob;
    if (typeof blob === 'number' && blob > 1000) {
      const raw = await cdp.eval('String(window.GameInterface.storage.getItem("SF2User"))');
      fs.mkdirSync(path.join(ROOT, 'mod', 'tests', 'fixtures'), { recursive: true });
      const f = path.join(ROOT, 'mod', 'tests', 'fixtures', 'SF2User.b64');
      fs.writeFileSync(f, raw);
      checks.fixtureSaved = f;
      const packs = await cdp.eval('(function(){try{var v=window.GameInterface.storage.getItem("SF2Packs");return v?String(v):""}catch(e){return ""}})()');
      if (packs && packs.length > 100) {
        const pf = path.join(ROOT, 'mod', 'tests', 'fixtures', 'SF2Packs.xml');
        fs.writeFileSync(pf, packs);
        checks.packsFixtureSaved = pf + ' (' + packs.length + ' B)';
      }
    }
  }

  const errs = cdp.events
    .filter((e) => e.method === 'Runtime.exceptionThrown' ||
      (e.method === 'Log.entryAdded' && e.params && e.params.entry && e.params.entry.level === 'error'))
    .map((e) => e.method === 'Runtime.exceptionThrown'
      ? (e.params.exceptionDetails.text + ' :: ' + ((e.params.exceptionDetails.exception || {}).description || ''))
      : e.params.entry.text)
    .filter((t) => !/favicon|net::ERR|ERR_FAILED|ERR_ABORTED/i.test(t));

  console.log('\n================ smoke results ================');
  for (const [k, v] of Object.entries(checks)) console.log('  ' + k.padEnd(18) + ' = ' + v);
  console.log('  consoleErrors      = ' + (errs.length ? '\n    - ' + errs.slice(0, 6).join('\n    - ') : 'none'));

  const pass = !!checks.overlayLoaded && checks.gameInterface === 'object' && !!checks.standaloneForced &&
    Number(checks.canvases) > 0 && !!checks.lobbyUILoaded && Number(checks.frames) > 60;
  console.log('===============================================');
  console.log(pass ? 'RESULT: PASS - standalone boot OK, LAN overlay live' : 'RESULT: FAIL - see checks above');
  try { proc.kill(); } catch {}
  try { srv.kill(); } catch {}
  process.exit(pass ? 0 : 1);
})().catch((e) => { console.error('[smoke] error:', e); process.exit(3); });
