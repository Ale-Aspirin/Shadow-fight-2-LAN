SF2 LAN Duel Room - FRIEND PACK  (mod v0.1.0, protocol 1)
=============================================================

You do NOT need anyone's game folder. Install the game yourself,
then apply this small mod pack. Takes ~2 minutes.

WHAT YOU NEED
  1. Shadow Fight 2 (Microsoft Store, Famobi edition) installed
  2. Node.js LTS  (https://nodejs.org - just Next/Next/Install)
  3. This pack unzipped anywhere, e.g. Documents\SF2-LAN\

SETUP (once)
  1. Double-click  mod\launcher\Install.cmd
     - copies YOUR Store game into game\ (never touches the Store package)
     - applies the LAN overlay. Wait for "[OK] Setup done".
  2. Check versions match your friend: open the game panel footer,
     both must show "mod v0.1.0". If not, get a fresh pack from them.

PLAY 1v1 (same WiFi)
  1. BOTH: run  mod\launcher\Play.cmd  (leave the relay window open).
  2. BOTH: click LAN (top-right), play one solo fight, Re-read.
  3. HOST: "I am the host" -> "Copy my IP" -> send IP to friend.
  4. FRIEND: type IP -> Join. Both see YOU vs FOE.
  5. Duel -> Start round -> fight the agreed stage at the same time.
  6. I won / I lost (both report). Rematch keeps score.
  7. TEST live link: during FIGHT watch "live inputs" (10Hz ghost HUD).
     Optional: tick "Mirror foe inputs" - BOTH steer ONE fighter (proof
     the link drives the engine; turn OFF for real duels).

IF JOIN HANGS
  - Same WiFi? No guest-isolation / VPN.
  - Host firewall: allow Node.js (private) or open TCP 8789 inbound.
  - In a browser try  http://<host-ip>:8789/lan  (expect relay text).

Full guide: HOW-TO-PLAY-LAN.md
