#!/usr/bin/env node
/**
 * SF2 LAN Duel Room - friend-pack exporter (zero npm deps).
 * Your friend does NOT need your 578 MB game/ folder. He installs the Store
 * game himself, then applies this small mod pack (same version as yours).
 *
 * Usage:  node mod\tools\export-pack.mjs
 * Output: SF2-LAN-friend-pack-v<mod>.zip  (in project root)
 */
import fs from 'node:fs';
import path from 'node:path';
import { execFileSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(HERE, '..', '..');
const pkg = JSON.parse(fs.readFileSync(path.join(ROOT, 'mod', 'package.json'), 'utf8'));
const VER = pkg.version;
const ZIP = path.join(ROOT, `SF2-LAN-friend-pack-v${VER}.zip`);
const STAGE = path.join(ROOT, 'dist', 'SF2-LAN');

const log = (...a) => console.log('[export]', ...a);

function rmrf(p) {
  if (!fs.existsSync(p)) return;
  fs.rmSync(p, { recursive: true, force: true });
}
function copyDir(src, dst, skip = []) {
  fs.mkdirSync(dst, { recursive: true });
  for (const e of fs.readdirSync(src, { withFileTypes: true })) {
    if (skip.includes(e.name)) continue;
    const s = path.join(src, e.name), d = path.join(dst, e.name);
    if (e.isDirectory()) copyDir(s, d, skip);
    else fs.copyFileSync(s, d);
  }
}

// 1. Stage a clean tree (mod-only: game/ profile/ saves/ logs stay home).
log('staging friend pack v' + VER + ' ...');
rmrf(STAGE);
fs.mkdirSync(STAGE, { recursive: true });
copyDir(path.join(ROOT, 'mod'), path.join(STAGE, 'mod'));
for (const f of ['HOW-TO-PLAY-LAN.md', 'REALTIME-FINDINGS.md']) {
  if (fs.existsSync(path.join(ROOT, f))) fs.copyFileSync(path.join(ROOT, f), path.join(STAGE, f));
}

const readme = [
  `SF2 LAN Duel Room - FRIEND PACK  (mod v${VER}, protocol 1)`,
  `=============================================================`,
  ``,
  `You do NOT need anyone's game folder. Install the game yourself,`,
  `then apply this small mod pack. Takes ~2 minutes.`,
  ``,
  `WHAT YOU NEED`,
  `  1. Shadow Fight 2 (Microsoft Store, Famobi edition) installed`,
  `  2. Node.js LTS  (https://nodejs.org - just Next/Next/Install)`,
  `  3. This pack unzipped anywhere, e.g. Documents\\SF2-LAN\\`,
  ``,
  `SETUP (once)`,
  `  1. Double-click  mod\\launcher\\Install.cmd`,
  `     - copies YOUR Store game into game\\ (never touches the Store package)`,
  `     - applies the LAN overlay. Wait for "[OK] Setup done".`,
  `  2. Check versions match your friend: open the game panel footer,`,
  `     both must show "mod v${VER}". If not, get a fresh pack from them.`,
  ``,
  `PLAY 1v1 (same WiFi)`,
  `  1. BOTH: run  mod\\launcher\\Play.cmd  (leave the relay window open).`,
  `  2. BOTH: click LAN (top-right), play one solo fight, Re-read.`,
  `  3. HOST: "I am the host" -> "Copy my IP" -> send IP to friend.`,
  `  4. FRIEND: type IP -> Join. Both see YOU vs FOE.`,
  `  5. Duel -> Start round -> fight the agreed stage at the same time.`,
  `  6. I won / I lost (both report). Rematch keeps score.`,
  `  7. TEST live link: during FIGHT watch "live inputs" (10Hz ghost HUD).`,
  `     Optional: tick "Mirror foe inputs" - BOTH steer ONE fighter (proof`,
  `     the link drives the engine; turn OFF for real duels).`,
  ``,
  `IF JOIN HANGS`,
  `  - Same WiFi? No guest-isolation / VPN.`,
  `  - Host firewall: allow Node.js (private) or open TCP 8789 inbound.`,
  `  - In a browser try  http://<host-ip>:8789/lan  (expect relay text).`,
  ``,
  `Full guide: HOW-TO-PLAY-LAN.md`,
  ``
].join('\r\n');
fs.writeFileSync(path.join(STAGE, 'README-FRIEND.txt'), readme, 'utf8');
fs.writeFileSync(path.join(STAGE, 'VERSION.txt'), `mod ${VER} protocol 1 exported ${new Date().toISOString()}\n`, 'utf8');

// 2. Zip via PowerShell (Windows built-in, no deps).
if (fs.existsSync(ZIP)) fs.unlinkSync(ZIP);
log('zipping ...');
execFileSync('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command',
  `Compress-Archive -Path ${JSON.stringify(path.join('dist', 'SF2-LAN', '*'))} -DestinationPath ${JSON.stringify(path.basename(ZIP))} -Force`],
  { cwd: ROOT, stdio: 'inherit', timeout: 120000 });
rmrf(path.join(ROOT, 'dist'));

const mb = (fs.statSync(ZIP).size / 1048576).toFixed(2);
console.log(`\n[export] done: ${path.basename(ZIP)} (${mb} MB, mod-only, no game files)`);
console.log('[export] Send that ONE zip to your friend (Discord/USB).');
console.log('[export] Both PCs: same zip version, each runs Install.cmd once, then Play.cmd to 1v1.\n');
