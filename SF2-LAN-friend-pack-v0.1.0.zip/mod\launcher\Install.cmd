@echo off
REM SF2 LAN Duel Room - one-time setup (needs the Microsoft Store version of
REM Shadow Fight 2 installed). Copies the game into game\ and applies the mod.
REM Leaves the window open with the result, success or failure.
setlocal
set "ROOT=%~dp0..\.."
for %%I in ("%ROOT%") do set "ROOT=%%~fI"
cd /d "%ROOT%"
where node >nul 2>nul || goto :no_node
node --version
node "mod\tools\install.mjs"
if errorlevel 1 goto :failed
if not exist "game\index.html" goto :incomplete
if not exist "game\lan\lan.js" goto :incomplete
echo.
echo [OK] Setup done. Now run mod\launcher\Play.cmd to play.
echo      (Keep this folder as-is; your friend needs the same friend-pack version.)
pause
endlocal
exit /b 0

:no_node
echo [X] Node.js not found in PATH.
echo     Install LTS from https://nodejs.org (tick "Add to PATH"), restart this window, retry.
echo     Still stuck? Run mod\launcher\Diagnose.cmd and send diagnostics.txt back.
pause
endlocal
exit /b 1

:failed
echo.
echo [X] Install failed - read the message above.
echo     Tip: is Shadow Fight 2 (Microsoft Store, Famobi edition) installed?
echo     Run mod\launcher\Diagnose.cmd and send diagnostics.txt to your friend.
pause
endlocal
exit /b 1

:incomplete
echo.
echo [X] Install finished but game\index.html or game\lan\lan.js is missing.
echo     Disk full? Antivirus quarantine? Rerun this script; if it repeats,
echo     run mod\launcher\Diagnose.cmd and send diagnostics.txt to your friend.
pause
endlocal
exit /b 1
