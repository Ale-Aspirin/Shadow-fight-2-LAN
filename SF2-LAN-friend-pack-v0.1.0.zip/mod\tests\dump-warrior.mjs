#!/usr/bin/env node
/* Prints the raw Warrior / CurrentUser shapes from the captured save. */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import * as C from '../overlay/sf2codec.mjs';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const fx = path.join(HERE, 'fixtures');
const raw = fs.readFileSync(path.join(fx, 'SF2User.b64'), 'utf8').trim();
const xml = C.decodeUsers(raw);
const tree = C.parseXml(xml);
const cur = C.find(tree, 'CurrentUser');
console.log('CurrentUser attrs:', JSON.stringify(cur ? cur.attrs : null));
console.log('CurrentUser children:', cur ? cur.children.map((c) => c.name + '@' + Object.keys(c.attrs).join(',')).join(' | ') : null);

const spans = C.warriorSpans(xml);
console.log('\nwarriors:', spans.length);
for (const s of spans) {
  console.log('\n--- warrior attrs (' + Object.keys(s.attrs).length + ') ---');
  console.log(JSON.stringify(s.attrs, null, 1));
  const w = C.parseXml(s.xml);
  const wroot = w.children[0];
  console.log('warrior child nodes:', wroot ? wroot.children.map((c) => c.name + '[' + Object.keys(c.attrs).join(',') + ']').slice(0, 20).join(' ') : null);
  console.log('\n--- warrior raw XML head ---\n' + s.xml.slice(0, 1800));
}
