@echo off
REM SF2 LAN Duel Room - diagnostics collector.
REM Run this on the PC that has the problem, then send diagnostics.txt back.
setlocal
set "ROOT=%~dp0..\.."
for %%I in ("%ROOT%") do set "ROOT=%%~fI"
cd /d "%ROOT%"
set "OUT=diagnostics.txt"
echo SF2-LAN diagnostics (%date% %time%)> "%OUT%" 2>&1
echo ============================================>> "%OUT%" 2>&1
echo [Windows]>> "%OUT%" 2>&1
ver>> "%OUT%" 2>&1
echo.>> "%OUT%" 2>&1
echo [Node]>> "%OUT%" 2>&1
where node>> "%OUT%" 2>&1
node --version>> "%OUT%" 2>&1
echo.>> "%OUT%" 2>&1
echo [Browsers]>> "%OUT%" 2>&1
where msedge.exe>> "%OUT%" 2>&1
where chrome.exe>> "%OUT%" 2>&1
where brave.exe>> "%OUT%" 2>&1
if exist "C:\Program Files\Microsoft\Edge\Application\msedge.exe" echo found: C:\Program Files\Microsoft\Edge\Application\msedge.exe>> "%OUT%" 2>&1
if exist "C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe" echo found: C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe>> "%OUT%" 2>&1
if exist "C:\Program Files\Google\Chrome\Application\chrome.exe" echo found: C:\Program Files\Google\Chrome\Application\chrome.exe>> "%OUT%" 2>&1
echo.>> "%OUT%" 2>&1
echo [Store game package]>> "%OUT%" 2>&1
powershell.exe -NoProfile -NonInteractive -Command "Get-AppxPackage | Where-Object { $_.Name -like '*ShadowFight*' } | Select-Object Name, Version, InstallLocation | Format-List" >> "%OUT%" 2>&1
echo.>> "%OUT%" 2>&1
echo [Mod version]>> "%OUT%" 2>&1
type "mod\package.json">> "%OUT%" 2>&1
echo.>> "%OUT%" 2>&1
echo [game folder]>> "%OUT%" 2>&1
if exist "game\index.html" (echo game\index.html: PRESENT>> "%OUT%" 2>&1) else (echo game\index.html: MISSING - Install.cmd did not finish>> "%OUT%" 2>&1)
if exist "game\lan\lan.js" (echo game\lan\lan.js: PRESENT>> "%OUT%" 2>&1) else (echo game\lan\lan.js: MISSING>> "%OUT%" 2>&1)
echo.>> "%OUT%" 2>&1
echo [Ports 8788/8789]>> "%OUT%" 2>&1
netstat -ano 2>nul | findstr "8788 8789">> "%OUT%" 2>&1
echo (empty above = nothing listening)>> "%OUT%" 2>&1
echo.>> "%OUT%" 2>&1
echo [Relay probe: http://127.0.0.1:8788/index.html]>> "%OUT%" 2>&1
node -e "require('http').get('http://127.0.0.1:8788/index.html',{timeout:3000},r=>{console.log('HTTP '+r.statusCode+' - relay is UP');process.exit(0)}).on('error',e=>{console.log('UNREACHABLE ('+e.message+') - relay is DOWN');process.exit(0)})" >> "%OUT%" 2>&1
echo.>> "%OUT%" 2>&1
echo [play.log tail]>> "%OUT%" 2>&1
powershell.exe -NoProfile -NonInteractive -Command "if (Test-Path 'play.log') { Get-Content 'play.log' -Tail 20 } else { 'no play.log yet (Play.cmd never ran?)' }" >> "%OUT%" 2>&1
echo.>> "%OUT%" 2>&1
echo [profile\relay.log tail]>> "%OUT%" 2>&1
powershell.exe -NoProfile -NonInteractive -Command "if (Test-Path 'profile\\relay.log') { Get-Content 'profile\\relay.log' -Tail 20 } else { 'no profile\\relay.log yet (Play.cmd never got as far as starting the relay)' }" >> "%OUT%" 2>&1
echo.>> "%OUT%" 2>&1
echo (Tip: play.log is the fresh trace from the last Play.cmd run.)>> "%OUT%" 2>&1
echo.
echo Done. File created: %ROOT%\%OUT%
echo Send diagnostics.txt to your friend (Discord / WhatsApp / USB).
pause
endlocal
exit /b 0
