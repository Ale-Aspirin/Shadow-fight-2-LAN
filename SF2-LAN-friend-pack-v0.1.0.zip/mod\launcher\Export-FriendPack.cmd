@echo off
REM SF2 LAN Duel Room - build the small friend pack (mod-only zip, no game files).
setlocal
set "ROOT=%~dp0..\.."
for %%I in ("%ROOT%") do set "ROOT=%%~fI"
cd /d "%ROOT%"
where node >nul 2>nul || (echo [X] Node.js not found in PATH. Install it from https://nodejs.org & pause & exit /b 1)
node "mod\tools\export-pack.mjs"
if errorlevel 1 (echo [X] Export failed. & pause & exit /b 1)
echo.
echo [OK] Send the SF2-LAN-friend-pack zip to your friend. They run Install.cmd, then you 1v1.
pause
endlocal
