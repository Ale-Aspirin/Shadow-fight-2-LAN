@echo off
REM SF2 LAN Duel Room - play (starts relay + static server, opens the game).
REM If anything fails, the window STAYS OPEN with an [X] message.
REM A full trace is written to play.log (and profile\relay.log for the relay).
setlocal
set "ROOT=%~dp0..\.."
for %%I in ("%ROOT%") do set "ROOT=%%~fI"
cd /d "%ROOT%"
echo [%date% %time%] Play.cmd started > "play.log" 2>&1

where node >nul 2>nul
if errorlevel 1 goto :no_node
for /f "tokens=1 delims=v." %%v in ('node --version 2^>nul') do set "NODEV=%%v"
echo node version: %NODEV%>> "play.log" 2>&1
node --version>> "play.log" 2>&1

if not exist "game\index.html" goto :no_game

REM --- sync overlay (visible; previously hidden, which swallowed the real error)
echo [play] syncing overlay (fast, reuses files)...
call node "mod\tools\install.mjs" >> "play.log" 2>&1
if errorlevel 1 goto :install_fail
if not exist "game\index.html" goto :no_game
if not exist "game\lan\lan.js" goto :no_overlay

if not exist "profile\play" mkdir "profile\play" >nul 2>nul

REM --- relay already running? (previous Play.cmd left it up) reuse it.
call :probe && goto :relay_ok
echo [play] starting relay (static 127.0.0.1:8788, lan 0.0.0.0:8789)...
>> "profile\relay.log" 2>&1 echo.
echo [%date% %time%] --- relay started by Play.cmd --- >> "profile\relay.log" 2>&1
start "SF2 LAN relay" /min cmd /c node mod\server\lan-server.mjs ^>^> profile\relay.log 2^>^&1
REM --- wait up to ~12s for the relay to answer
set "TRIES=0"
:wait_relay
call :probe && goto :relay_ok
set /a TRIES+=1
if %TRIES% GEQ 12 goto :relay_fail
timeout /t 1 /nobreak >nul
goto :wait_relay

:relay_ok
echo [play] relay is up: http://127.0.0.1:8788/index.html
goto :open_browser

:open_browser
set "URL=http://127.0.0.1:8788/index.html"
set "PROFILE=%ROOT%\profile\play"
set "BROWSER="
if exist "C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe" set "BROWSER=C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"
if exist "C:\Program Files\Microsoft\Edge\Application\msedge.exe" set "BROWSER=C:\Program Files\Microsoft\Edge\Application\msedge.exe"
if exist "C:\Program Files\Google\Chrome\Application\chrome.exe" if not defined BROWSER set "BROWSER=C:\Program Files\Google\Chrome\Application\chrome.exe"
if not defined BROWSER for /f "delims=" %%b in ('where msedge.exe 2^>nul') do if not defined BROWSER set "BROWSER=%%b"
if not defined BROWSER for /f "delims=" %%b in ('where chrome.exe 2^>nul') do if not defined BROWSER set "BROWSER=%%b"
if not defined BROWSER for /f "delims=" %%b in ('where brave.exe 2^>nul') do if not defined BROWSER set "BROWSER=%%b"
echo browser: %BROWSER%>> "play.log" 2>&1

if defined BROWSER (
  echo [play] opening game in app window...
  start "" "%BROWSER%" --app=%URL% --user-data-dir="%PROFILE%" --no-first-run --no-default-browser-check --disable-sync --window-size=1100,700
) else (
  echo [play] no Edge/Chrome/Brave found - opening default browser instead.
  echo        For the best experience, install Edge or Chrome.
  start "" "%URL%"
)
echo.
echo [play] game should now be open. In the game click LAN (top-right).
echo        Host: "I am the host" -^> "Copy my IP". Friend: type IP -^> Join.
echo        Leave the "SF2 LAN relay" window open while playing.
echo        Press any key to open the game URL again, or close this window.
pause >nul
if defined BROWSER ( start "" "%BROWSER%" --app=%URL% --user-data-dir="%PROFILE%" ) else ( start "" "%URL%" )
endlocal
exit /b 0

:probe
node -e "require('http').get('http://127.0.0.1:8788/index.html',{timeout:1500},r=>process.exit(r.statusCode===200?0:1)).on('error',()=>process.exit(1)).on('timeout',()=>process.exit(1))" >nul 2>&1
exit /b %errorlevel%

:no_node
echo [X] Node.js not found in PATH.>> "play.log" 2>&1
echo [X] Node.js not found.
echo     Install LTS from https://nodejs.org (tick "Add to PATH"), restart, retry.
echo     Still stuck? Run mod\launcher\Diagnose.cmd and send diagnostics.txt back.
pause
endlocal
exit /b 1

:no_game
echo [X] game\index.html missing.>> "play.log" 2>&1
echo [X] game folder is empty or Install did not finish.
echo     Run mod\launcher\Install.cmd first and wait for "[OK] Setup done".
pause
endlocal
exit /b 1

:no_overlay
echo [X] game\lan\lan.js missing after sync.>> "play.log" 2>&1
echo [X] Overlay files missing - sync failed. See play.log, or rerun Install.cmd.
pause
endlocal
exit /b 1

:install_fail
echo [X] overlay sync failed. Last lines of play.log:>> "play.log" 2>&1
echo [X] Overlay sync (install.mjs) failed. See above + play.log.
echo     Common cause: Store game not found. Run Diagnose.cmd to check.
pause
endlocal
exit /b 1

:relay_fail
echo [X] relay did not answer on 127.0.0.1:8788 after 12s.>> "play.log" 2>&1
echo [X] Relay did not start. Likely causes:
echo     1) Ports 8788/8789 busy - close other Play.cmd / relay windows, retry.
echo     2) Relay crashed - see profile\relay.log tail:
type "profile\relay.log" 2>nul
echo     3) Antivirus/firewall blocked node. Allow Node.js on private networks.
echo     Run mod\launcher\Diagnose.cmd and send diagnostics.txt back.
pause
endlocal
exit /b 1
