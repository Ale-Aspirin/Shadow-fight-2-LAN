#!/usr/bin/env node
/* ============================================================================
 * SF2 LAN Duel Room - local server (zero npm dependencies)
 *
 *   --static 127.0.0.1:8788   serves game\ to the local browser (this PC only)
 *   --lan    0.0.0.0:8789     relay + matchmaking WebSocket endpoint (ws://…/lan)
 *
 * Nothing here talks to the internet. The only traffic is your own WiFi.
 * ==========================================================================*/
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import os from 'node:os';
import { fileURLToPath } from 'node:url';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(HERE, '..', '..');
const GAME_DIR = path.join(ROOT, 'game');
const MOD_VERSION = JSON.parse(fs.readFileSync(path.join(ROOT, 'mod', 'package.json'), 'utf8')).version;
const PROTOCOL = 1;

function arg(name, def) {
  const i = process.argv.indexOf('--' + name);
  return i >= 0 && process.argv[i + 1] ? process.argv[i + 1] : def;
}
const STATIC_ADDR = arg('static', '127.0.0.1:8788');
const LAN_ADDR = arg('lan', '0.0.0.0:8789');
const QUIET = process.argv.includes('--quiet');
const log = (...a) => { if (!QUIET) console.log('[sf2lan]', ...a); };

const splitAddr = (s) => { const i = s.lastIndexOf(':'); return { host: s.slice(0, i), port: Number(s.slice(i + 1)) }; };

/* ------------------------------------------------------------------ helpers */
const MIME = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8',
  '.mjs': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8', '.xml': 'application/xml; charset=utf-8',
  '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.webp': 'image/webp',
  '.avif': 'image/avif', '.gif': 'image/gif', '.ico': 'image/x-icon', '.svg': 'image/svg+xml',
  '.mp4': 'video/mp4', '.webm': 'video/webm', '.mp3': 'audio/mpeg', '.ogg': 'audio/ogg',
  '.wav': 'audio/wav', '.woff': 'font/woff', '.woff2': 'font/woff2', '.ttf': 'font/ttf',
  '.txt': 'text/plain; charset=utf-8', '.dat': 'application/octet-stream',
  '.wasm': 'application/wasm', '.map': 'application/json; charset=utf-8'
};
const mimeOf = (p) => MIME[path.extname(p).toLowerCase()] || 'application/octet-stream';

/** All non-loopback IPv4 addresses -> what the host shows to a friend. */
function lanAddresses() {
  const out = [];
  const ifs = os.networkInterfaces();
  for (const name of Object.keys(ifs)) {
    for (const ni of ifs[name] || []) {
      if (ni.family === 'IPv4' && !ni.internal) out.push({ name, address: ni.address });
    }
  }
  return out;
}

/* ------------------------------------------------------------- static server */
function serveStatic(req, res) {
  let urlPath;
  try { urlPath = decodeURIComponent(new URL(req.url, 'http://x').pathname); } catch { urlPath = '/'; }
  if (urlPath === '/' || urlPath === '') urlPath = '/index.html';
  const target = path.join(GAME_DIR, path.normalize(urlPath).replace(/^[\\/]+/, ''));
  if (!target.startsWith(GAME_DIR)) { res.writeHead(403).end('forbidden'); return; }
  fs.stat(target, (err, st) => {
    if (err || !st.isFile()) { res.writeHead(404).end('not found'); return; }
    const head = {
      'Content-Type': mimeOf(target),
      'Cache-Control': 'no-store',
      'Accept-Ranges': 'bytes'
    };
    fs.readFile(target, (e2, buf) => {
      if (e2) { res.writeHead(500).end('read error'); return; }
      const range = req.headers.range;
      if (range && /^bytes=\d*-\d*$/.test(range)) {
        const [s, en] = range.replace('bytes=', '').split('-');
        const start = s ? parseInt(s, 10) : Math.max(0, buf.length - parseInt(en, 10));
        const end = (en && s) ? parseInt(en, 10) : buf.length - 1;
        if (start >= buf.length || end >= buf.length || start > end) {
          res.writeHead(416, { 'Content-Range': `bytes */${buf.length}` }).end();
          return;
        }
        head['Content-Range'] = `bytes ${start}-${end}/${buf.length}`;
        head['Content-Length'] = end - start + 1;
        res.writeHead(206, head).end(buf.subarray(start, end + 1));
        return;
      }
      head['Content-Length'] = buf.length;
      res.writeHead(200, head).end(buf);
    });
  });
}
/* ------------------------------------------------------------------ websocket */
const WS_GUID = '258EAFA5-E914-47DA-95CA-C5AB0DC85B11';

class WS {
  constructor(socket, id) {
    this.socket = socket;
    this.id = id;
    this.buf = Buffer.alloc(0);
    this.frag = [];
    this.open = true;
    this.onMessage = null;
    this.onClose = null;
    this.meta = {};
    socket.on('data', (c) => this._data(c));
    socket.on('error', () => this._closed());
    socket.on('close', () => this._closed());
    socket.setNoDelay(true);
  }
  static upgrade(req, socket, id) {
    const key = req.headers['sec-websocket-key'];
    const accept = crypto.createHash('sha1').update(key + WS_GUID).digest('base64');
    socket.write(
      'HTTP/1.1 101 Switching Protocols\r\n' +
      'Upgrade: websocket\r\n' +
      'Connection: Upgrade\r\n' +
      'Sec-WebSocket-Accept: ' + accept + '\r\n\r\n'
    );
    return new WS(socket, id);
  }
  sendText(s) { this._frame(0x1, Buffer.from(s, 'utf8')); }
  sendJSON(o) { this.sendText(JSON.stringify(o)); }
  ping() { this._frame(0x9, Buffer.alloc(0)); }
  close(code = 1000, reason = '') {
    if (!this.open) return;
    const b = Buffer.alloc(2 + Buffer.byteLength(reason));
    b.writeUInt16BE(code, 0);
    b.write(reason, 2);
    this._frame(0x8, b);
    this.open = false;
    try { this.socket.end(); } catch { /* noop */ }
  }
  _frame(opcode, payload) {
    if (!this.open || !this.socket.writable) return;
    const len = payload.length;
    let head;
    if (len < 126) { head = Buffer.alloc(2); head[1] = len; }
    else if (len < 65536) { head = Buffer.alloc(4); head[1] = 126; head.writeUInt16BE(len, 2); }
    else { head = Buffer.alloc(10); head[1] = 127; head.writeBigUInt64BE(BigInt(len), 2); }
    head[0] = 0x80 | opcode;
    try { this.socket.write(Buffer.concat([head, payload])); } catch (e) { this._closed(); }
  }
  _data(chunk) {
    this.buf = Buffer.concat([this.buf, chunk]);
    for (;;) {
      const b = this.buf;
      if (b.length < 2) return;
      const fin = (b[0] & 0x80) !== 0;
      const opcode = b[0] & 0x0f;
      const masked = (b[1] & 0x80) !== 0;
      let len = b[1] & 0x7f;
      let off = 2;
      if (len === 126) { if (b.length < 4) return; len = b.readUInt16BE(2); off = 4; }
      else if (len === 127) { if (b.length < 10) return; len = Number(b.readBigUInt64BE(2)); off = 10; }
      if (len > 4 * 1024 * 1024) { this.close(1009, 'too big'); return; }
      let mask = null;
      if (masked) { if (b.length < off + 4) return; mask = b.subarray(off, off + 4); off += 4; }
      if (b.length < off + len) return;
      let payload = b.subarray(off, off + len);
      if (mask) { payload = Buffer.from(payload); for (let i = 0; i < payload.length; i++) payload[i] ^= mask[i & 3]; }
      this.buf = b.subarray(off + len);

      if (opcode === 0x8) { this.close(1000, 'bye'); return; }
      if (opcode === 0x9) { this._frame(0xa, payload); continue; }
      if (opcode === 0xa) { continue; }
      if (opcode === 0x1 || opcode === 0x2) { this.frag = [payload]; }
      else if (opcode === 0x0) { this.frag.push(payload); }
      else { continue; }
      if (fin) {
        const full = Buffer.concat(this.frag);
        this.frag = [];
        this._emit(full.toString('utf8'));
      }
    }
  }
  _emit(text) {
    let msg = null;
    try { msg = JSON.parse(text); } catch (e) { return; }
    if (this.onMessage) { try { this.onMessage(msg); } catch (e) { log('handler error:', e.message); } }
  }
  _closed() {
    if (!this.open) return;
    this.open = false;
    if (this.onClose) { try { this.onClose(); } catch (e) { /* noop */ } }
  }
}
/* -------------------------------------------------------------- LAN "room" */
let nextId = 1;
const clients = new Map();          // id -> { ws, nick, card, joinedAt }
const HEARTBEAT_MS = 15000;

function roster() {
  // Only hello'd players are visible. Sockets that connected but have not
  // sent hello yet (nick == null) are pending and must not appear, otherwise
  // clients race on rosters containing null nicks/cards. Internal __probe__
  // sockets (IP lookup) are hidden too.
  return [...clients.values()]
    .filter((c) => c.nick != null && !String(c.nick).startsWith('__probe__'))
    .map((c) => ({
      id: c.ws.id, nick: c.nick, card: c.card || null, since: c.joinedAt
    }));
}
function broadcast(obj, exceptId = null) {
  for (const c of clients.values()) if (c.ws.id !== exceptId && c.ws.open) c.ws.sendJSON(obj);
}
function sendTo(id, obj) {
  const c = clients.get(id);
  if (c && c.ws.open) c.ws.sendJSON(obj);
  return !!c;
}
function pushRoster() { broadcast({ t: 'roster', peers: roster() }); }

function onMessage(ws, msg) {
  const c = clients.get(ws.id);
  switch (msg.t) {
    case 'hello': {
      if (Number(msg.proto) !== PROTOCOL || String(msg.mod) !== MOD_VERSION) {
        ws.sendJSON({
          t: 'reject',
          reason: 'Version mismatch: host runs mod ' + MOD_VERSION + ' (proto ' + PROTOCOL + '), you run mod ' +
            (msg.mod || '?') + ' (proto ' + (msg.proto || '?') + '). Both PCs must run the same SF2-LAN mod.'
        });
        setTimeout(() => ws.close(1008, 'version'), 250);
        return;
      }
      c.nick = String(msg.nick || 'player').slice(0, 24);
      c.card = msg.card || null;
      c.joinedAt = Date.now();
      ws.sendJSON({
        t: 'welcome', id: ws.id, mod: MOD_VERSION, proto: PROTOCOL,
        nick: c.nick, addresses: lanAddresses(), peers: roster()
      });
      if (String(c.nick).startsWith('__probe__')) return; // IP lookup only: no join/roster spam
      broadcast({ t: 'join', id: ws.id, nick: c.nick }, ws.id);
      pushRoster();
      log('joined:', c.nick, '#' + ws.id, '(' + roster().length + ' in room)');
      return;
    }
    case 'card': {
      if (!c) return;
      c.card = msg.card || null;
      pushRoster();
      return;
    }
    case 'chat': {
      if (!c) return;
      const text = String(msg.text == null ? '' : msg.text).slice(0, 400);
      if (!text) return;
      broadcast({ t: 'chat', from: ws.id, nick: c.nick, text, ts: Date.now() });
      return;
    }
    case 'ping': {
      ws.sendJSON({ t: 'pong', ts: msg.ts, now: Date.now() });
      return;
    }
    default: {
      // everything else with a target is relayed verbatim (duel.req/accept/launch/result/...)
      if (msg.to != null) {
        const ok = sendTo(Number(msg.to), { ...msg, from: ws.id, fromNick: c ? c.nick : '?' });
        if (!ok) ws.sendJSON({ t: 'error', about: msg.t, reason: 'peer ' + msg.to + ' is gone' });
      }
      return;
    }
  }
}

function onClose(ws) {
  const c = clients.get(ws.id);
  clients.delete(ws.id);
  if (c && c.nick != null && !String(c.nick).startsWith('__probe__')) {
    broadcast({ t: 'left', id: ws.id, nick: c.nick }, ws.id);
    pushRoster();
    log('left:', c.nick, '#' + ws.id, '(' + roster().length + ' in room)');
  }
}

/* ------------------------------------------------------------ server startup */
function startLanServer() {
  const { host, port } = splitAddr(LAN_ADDR);
  const srv = http.createServer((req, res) => {
    res.writeHead(426, { 'Content-Type': 'text/plain' });
    res.end('SF2 LAN relay. Connect with:  new WebSocket("ws://<host-ip>:' + port + '/lan")');
  });
  srv.on('upgrade', (req, socket) => {
    if (!(req.url || '').startsWith('/lan') || !req.headers['sec-websocket-key']) { socket.destroy(); return; }
    const ws = WS.upgrade(req, socket, nextId++);
    clients.set(ws.id, { ws, nick: null, card: null, joinedAt: Date.now() });
    ws.onMessage = (m) => onMessage(ws, m);
    ws.onClose = () => onClose(ws);
    ws.sendJSON({ t: 'hello?', proto: PROTOCOL, mod: MOD_VERSION });
  });
  srv.listen(port, host, () => {
    const addrs = lanAddresses();
    console.log('\n================ SF2 LAN DUEL ROOM - relay online ================');
    console.log(' mod ' + MOD_VERSION + '  protocol ' + PROTOCOL + '  binding ' + host + ':' + port + '/lan');
    if (addrs.length) console.log(' share one of these IPs with your friend: ' + addrs.map((a) => a.address).join(', '));
    else console.log(' (no LAN IPv4 found - are you on WiFi?)');
    console.log('=================================================================\n');
  });
  const heartbeat = setInterval(() => {
    for (const c of clients.values()) { if (c.ws.open) c.ws.ping(); else onClose(c.ws); }
  }, HEARTBEAT_MS);
  heartbeat.unref?.();
  return srv;
}

function startStaticServer() {
  const { host, port } = splitAddr(STATIC_ADDR);
  const srv = http.createServer(serveStatic);
  srv.listen(port, host, () => log('serving game from ' + GAME_DIR + ' at http://' + host + ':' + port + '/'));
  return srv;
}

if (!fs.existsSync(path.join(GAME_DIR, 'index.html'))) {
  console.error('[sf2lan] game folder is empty. Run:  node mod\\tools\\install.mjs');
  process.exit(1);
}
startStaticServer();
startLanServer();

const pidFile = path.join(ROOT, 'profile', 'server.pid');
try { fs.mkdirSync(path.dirname(pidFile), { recursive: true }); fs.writeFileSync(pidFile, String(process.pid)); } catch { /* noop */ }
for (const sig of ['SIGINT', 'SIGTERM']) {
  process.on(sig, () => {
    try { fs.unlinkSync(pidFile); } catch { /* noop */ }
    log('shutting down');
    process.exit(0);
  });
}


