/* ============================================================================
 * SF2 LAN Duel Room - save codec + XML helpers  (ES module, browser + Node)
 *
 * Verified against the game code (sf2.js, build 1.0.6 / internal 1.0.13):
 *   storage key "SF2User"  : base64( uint32-LE utf8Length + utf8(XML of <Users>) [+ zero padding] )
 *                            written by Aa.save()   read by Aa.load()
 *   storage key "SF2Packs" : plain XML text (Aa.hka / Aa.OJ)
 *   storage key "SF2Flags" : small flags blob (not needed by us)
 * GameInterface.storage.getItem(name) returns those raw strings.
 * ==========================================================================*/

export const KEYS = { users: 'SF2User', packs: 'SF2Packs', flags: 'SF2Flags' };

/* ------------------------------------------------------------------ base64 */
const B64 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
export function bytesToB64(bytes) {
  let out = '';
  for (let i = 0; i < bytes.length; i += 3) {
    const b0 = bytes[i], b1 = bytes[i + 1], b2 = bytes[i + 2];
    out += B64[b0 >> 2];
    out += B64[((b0 & 3) << 4) | ((b1 === undefined ? 0 : b1) >> 4)];
    out += b1 === undefined ? '=' : B64[((b1 & 15) << 2) | ((b2 === undefined ? 0 : b2) >> 6)];
    out += b2 === undefined ? '=' : B64[b2 & 63];
  }
  return out;
}
export function b64ToBytes(b64) {
  const s = String(b64).replace(/[\r\n\s]/g, '').replace(/=+$/, '');
  const idx = (c) => {
    const i = B64.indexOf(c);
    if (i < 0) throw new Error('invalid base64 char: ' + c);
    return i;
  };
  const out = new Uint8Array(Math.floor((s.length * 3) / 4));
  let p = 0;
  for (let i = 0; i < s.length; i += 4) {
    const n = (idx(s[i]) << 18) | (idx(s[i + 1]) << 12) | ((i + 2 < s.length ? idx(s[i + 2]) : 0) << 6) | (i + 3 < s.length ? idx(s[i + 3]) : 0);
    if (p < out.length) out[p++] = (n >> 16) & 255;
    if (i + 2 < s.length && p < out.length) out[p++] = (n >> 8) & 255;
    if (i + 3 < s.length && p < out.length) out[p++] = n & 255;
  }
  return out.subarray(0, p);
}

const utf8Encode = (str) => new TextEncoder().encode(str);
const utf8Decode = (bytes) => new TextDecoder('utf-8').decode(bytes);

/* -------------------------------------------------- SF2User blob (de)coding */
/** base64 -> XML string. Layout: 4-byte little-endian UTF-8 byte length
 *  (Haxe BytesOutput.writeInt32 + writeString) + UTF-8 XML.
 *  NOTE: the game encodes `c.Oq().b.zv` (the full ArrayBuffer capacity, not
 *  the used length), so real saves carry zero padding past `len`. The game's
 *  own reader (`BytesInput.readInt32` + `readString(len)`, and `Bytes.toString`
 *  stops at the first NUL) ignores that padding. We do the same: honour `len`
 *  when it is sane, strip trailing NULs, and stay tolerant of header-less or
 *  BE blobs. Write path emits the minimal clean form (4 + len) which the game
 *  accepts. */
function stripPadding(s) {
  const nul = s.indexOf('\0');
  return nul >= 0 ? s.slice(0, nul) : s;
}
export function decodeUsers(b64) {
  const bytes = b64ToBytes(b64);
  if (bytes.length >= 4) {
    const le = (bytes[0] | (bytes[1] << 8) | (bytes[2] << 16) | (bytes[3] << 24)) >>> 0;
    const tail = bytes.subarray(4);
    const looksXml = (b) => b.length > 0 && b[0] === 60; // '<'
    if (looksXml(tail) && le <= tail.length) {
      // Exact match: clean blob with no padding.
      if (le === tail.length) return stripPadding(utf8Decode(tail));
      // Padded game blob: len bytes of XML + zero padding (capacity artifact).
      let padded = true;
      for (let i = le; i < tail.length; i++) {
        if (tail[i] !== 0) { padded = false; break; }
      }
      if (padded) {
        try { return stripPadding(utf8Decode(tail.subarray(0, le))); } catch { /* fallthrough */ }
      }
    }
    if (looksXml(tail)) {
      // header present but unusable - decode the tail tolerantly
      try {
        let t = stripPadding(utf8Decode(tail));
        if (t.includes('<')) return t.slice(t.indexOf('<'));
      } catch { /* fallthrough */ }
    }
  }
  const xml = stripPadding(utf8Decode(bytes));
  const lt = xml.indexOf('<');
  return lt > 0 ? xml.slice(lt) : xml;
}

/** XML string -> base64 that Aa.load() will accept. Minimal clean form:
 *  LE utf8-byte-length + utf8 bytes (the game also accepts its own padded
 *  form, but there is no reason to reproduce the capacity padding). */
export function encodeUsers(xml) {
  const clean = stripPadding(xml);
  const body = utf8Encode(clean);
  const out = new Uint8Array(body.length + 4);
  const len = body.length; // kb.f3(xml).length: UTF-8 byte count -> LE
  out[0] = len & 255;
  out[1] = (len >>> 8) & 255;
  out[2] = (len >>> 16) & 255;
  out[3] = (len >>> 24) & 255;
  out.set(body, 4);
  return bytesToB64(out);
}

/** Round-trip check used by tests + the overlay before writing anything. */
export function selfTest(b64) {
  const xml = decodeUsers(b64);
  const again = encodeUsers(xml);
  return { xml, reencoded: again, stable: decodeUsers(again) === xml };
}
/* --------------------------------------------------------- tiny XML parser */
const unescapeXml = (s) => s.replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&apos;/g, "'").replace(/&amp;/g, '&');
const escapeAttr = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

function tagEnd(xml, lt) {
  let q = null;
  for (let i = lt + 1; i < xml.length; i++) {
    const c = xml[i];
    if (q) { if (c === q) q = null; continue; }
    if (c === '"' || c === "'") { q = c; continue; }
    if (c === '>') return i;
  }
  return xml.length - 1;
}
function parseAttrs(s) {
  const out = {};
  const re = /([A-Za-z_][\w:.\-]*)\s*=\s*"([^"]*)"/g;
  let m;
  while ((m = re.exec(s))) out[m[1]] = unescapeXml(m[2]);
  return out;
}
/** Minimal, offset-preserving XML tree. Enough for the game's own generated XML. */
export function parseXml(xml) {
  const root = { name: '#root', attrs: {}, children: [], text: '', start: 0, end: xml.length, parent: null };
  const stack = [root];
  let i = 0;
  while (i < xml.length) {
    const lt = xml.indexOf('<', i);
    if (lt < 0) { stack[stack.length - 1].text += xml.slice(i); break; }
    if (lt > i) stack[stack.length - 1].text += xml.slice(i, lt);
    if (xml.startsWith('<?', lt)) { const e = xml.indexOf('?>', lt); i = e < 0 ? xml.length : e + 2; continue; }
    if (xml.startsWith('<!--', lt)) { const e = xml.indexOf('-->', lt); i = e < 0 ? xml.length : e + 3; continue; }
    if (xml.startsWith('<!', lt)) { const e = xml.indexOf('>', lt); i = e < 0 ? xml.length : e + 1; continue; }
    const gt = tagEnd(xml, lt);
    const raw = xml.slice(lt + 1, gt);
    if (raw.startsWith('/')) {
      const top = stack.pop();
      if (top) top.end = gt + 1;
      i = gt + 1;
      continue;
    }
    const selfClose = raw.endsWith('/');
    const body = selfClose ? raw.slice(0, -1) : raw;
    const sp = body.search(/\s/);
    const name = sp < 0 ? body : body.slice(0, sp);
    const node = { name, attrs: parseAttrs(sp < 0 ? '' : body.slice(sp)), children: [], text: '', start: lt, end: gt + 1, parent: stack[stack.length - 1] };
    stack[stack.length - 1].children.push(node);
    if (!selfClose) stack.push(node);
    i = gt + 1;
  }
  return root;
}
export function findAll(node, name) {
  const out = [];
  (function walk(n) { for (const c of n.children) { if (c.name === name) out.push(c); walk(c); } })(node);
  return out;
}
export function find(node, name) { return findAll(node, name)[0] || null; }
export function child(node, name) { return node ? node.children.find((c) => c.name === name) || null : null; }
export function attrsOf(node) { return node ? node.attrs : {}; }

/* ------------------------------------------------------- fighter extraction */
const GEAR_SLOTS = ['Weapon', 'Armor', 'Helmet', 'Ranged', 'Magic', 'Perk', 'Special'];
/** Pull a displayable fighter card out of the users XML. Defensive: schema may vary. */
export function extractFighter(usersXml) {
  const tree = parseXml(usersXml);
  const cur = find(tree, 'CurrentUser');
  const warriorsBox = find(tree, 'Warriors');
  const all = warriorsBox ? warriorsBox.children.filter((c) => c.name === 'Warrior' || GEAR_SLOTS.includes(c.name) || c.children.length) : [];
  const lastSlot = cur ? Number(cur.attrs.LastSaveSlot || 0) : 0;
  const real = all.filter((w) => String(w.attrs.IsFake || '') !== 'True');
  const chosen = real.find((w) => Number(w.attrs.SaveSlot || -1) === lastSlot) || real[0] || all[0] || null;

  const items = [];
  if (chosen) {
    for (const it of findAll(chosen, 'Item')) {
      items.push({
        slot: it.attrs.SlotType || it.attrs.Type || '?',
        subType: it.attrs.SubType || '',
        name: it.attrs.ItemName || it.attrs.Name || '',
        level: it.attrs.Level ? Number(it.attrs.Level) : undefined
      });
    }
  }
  const gear = {};
  for (const key of GEAR_SLOTS) if (chosen && chosen.attrs[key]) gear[key] = chosen.attrs[key];

  return {
    ok: !!chosen,
    name: (chosen && (chosen.attrs.Name || chosen.attrs.FirstName || chosen.attrs.UserName)) || (cur && cur.attrs.Name) || 'Fighter',
    level: chosen && chosen.attrs.Level ? Number(chosen.attrs.Level) : undefined,
    power: chosen && chosen.attrs.Rating ? Number(chosen.attrs.Rating) : undefined,
    saveSlot: chosen && chosen.attrs.SaveSlot != null ? Number(chosen.attrs.SaveSlot) : undefined,
    id: chosen && chosen.attrs.ID != null ? Number(chosen.attrs.ID) : undefined,
    gear,
    items,
    warriorCount: all.length,
    raw: chosen ? chosen.attrs : {}
  };
}

/** Raw XML text of the n-th Warriors/<Warrior> element (for clone-and-rename injection). */
export function warriorSpans(usersXml) {
  const tree = parseXml(usersXml);
  const box = find(tree, 'Warriors');
  if (!box) return [];
  return box.children
    .filter((c) => c.name === 'Warrior')
    .map((c) => ({ xml: usersXml.slice(c.start, c.end), attrs: c.attrs, start: c.start, end: c.end }));
}
/* ------------------------------------------- warrior clone + string patching */
/** Override/add attributes on the first (root) tag of an XML fragment, keeping
 *  the fragment byte-exact everywhere else. Used to clone the player's own
 *  warrior node and re-label it as the LAN opponent. */
export function patchFragmentAttrs(frag, overrides) {
  const lt = frag.indexOf('<');
  if (lt < 0) return frag;
  const gt = tagEnd(frag, lt);
  let tag = frag.slice(lt, gt);
  const selfClose = tag.endsWith('/');
  if (selfClose) tag = tag.slice(0, -1);
  for (const [k, v] of Object.entries(overrides)) {
    if (v == null) continue;
    const rx = new RegExp('(\\s' + k.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '\\s*=\\s*)"[^"]*"');
    if (rx.test(tag)) tag = tag.replace(rx, '$1"' + escapeAttr(v) + '"');
    else tag = tag + ' ' + k + '="' + escapeAttr(v) + '"';
  }
  if (selfClose) tag += '/';
  return frag.slice(0, lt) + tag + frag.slice(gt);
}

/** Insert text at a byte offset inside the XML (used to append a cloned warrior). */
export function insertAfterSpan(xml, offset, text) {
  return xml.slice(0, offset) + text + xml.slice(offset);
}

/** Convenience: full pipeline for a "friend in my game" patch. Returns
 *  { ok, xml, reason, injectedName, removed } and never throws.
 *  Phase-2: copies combat look/stats (not just the name), sets BOTH Name and
 *  FirstName (the game reads FirstName), keeps template Tactic/Items, replaces
 *  any previous injected clone so repeated presses stay at +1 warrior. */
const INJECT_COPY_ATTRS = ['Level', 'Experience', 'Power', 'Strength', 'Stamina', 'Weapon', 'Armor', 'Helm', 'Helmet', 'Ranged', 'Magic', 'Avatar', 'Skeleton', 'Voice'];
export function removeInjectedClones(usersXml) {
  const spans = warriorSpans(usersXml);
  const fakes = spans.filter((s) => String(s.attrs.IsFake || '') === 'True');
  if (!fakes.length) return { xml: usersXml, removed: 0 };
  // Remove from the end so earlier offsets stay valid.
  let xml = usersXml;
  const sorted = [...fakes].sort((a, b) => b.start - a.start);
  for (const s of sorted) xml = xml.slice(0, s.start) + xml.slice(s.end);
  return { xml, removed: fakes.length };
}
export function injectOpponentIntoUsers(usersXml, card, opts = {}) {
  try {
    const cleaned = removeInjectedClones(usersXml);
    let base = cleaned.xml;
    const spans = warriorSpans(base);
    if (!spans.length) return { ok: false, reason: 'no <Warrior> template in save' };
    const tmpl = spans.find((s) => String(s.attrs.IsFake || '') !== 'True') || spans[0];
    const foeName = (card && card.name) || 'Friend';
    const overrides = {
      Name: foeName,
      FirstName: foeName,
      IsFake: 'True',
      SaveSlot: tmpl.attrs.SaveSlot || '0'
    };
    // Unique ID: max existing + 9001 (wraps at 100k, avoids collisions).
    const maxId = spans.reduce((m, s) => Math.max(m, Number(s.attrs.ID || 0) || 0), 0);
    overrides.ID = String((maxId + 9001) % 100000);
    // Copy combat stats from the foe card when present.
    const raw = (card && card.raw) || {};
    for (const k of INJECT_COPY_ATTRS) {
      if (raw[k] != null && raw[k] !== '') overrides[k] = String(raw[k]);
    }
    const gear = (card && card.gear) || {};
    for (const [k, v] of Object.entries(gear)) {
      if (v != null && v !== '') overrides[k] = String(v);
    }
    if (card && card.level != null) overrides.Level = String(card.level);
    // Never copy identity/progress fields from the foe.
    for (const k of ['ServerUserID', 'Money', 'Tutorial', 'CurrentZone', 'Tactic', 'SaveSlot']) delete overrides[k];
    overrides.SaveSlot = tmpl.attrs.SaveSlot || '0';
    // Validate the patched XML before returning.
    const frag = patchFragmentAttrs(tmpl.xml, overrides);
    const patched = insertAfterSpan(base, tmpl.end, '\n\t\t\t' + frag);
    const check = warriorSpans(patched);
    if (check.length !== spans.length + 1) return { ok: false, reason: 'injection validation failed' };
    const added = check.find((s) => s.attrs.ID === overrides.ID);
    if (!added || (added.attrs.FirstName !== foeName && added.attrs.Name !== foeName)) {
      return { ok: false, reason: 'injected name missing after patch' };
    }
    return { ok: true, xml: patched, injectedName: foeName, removed: cleaned.removed, template: tmpl.attrs, overrides };
  } catch (e) {
    return { ok: false, reason: e.message };
  }
}


