/* ============================================================================
 * SF2 LAN Duel Room - pre-boot shim  (classic script)
 * Loaded from index.html *before* the boot script that calls GameInterface.init()
 * and SF2.main(). Runs in the page, needs no build step, never touches sf2.js.
 *
 * What it does:
 *   1. forces features.standalone = true  -> the game skips the Famobi portal /
 *      Sentry / cloud-save path and runs fully offline (saves go to local
 *      storage through GameInterface.storage).
 *   2. observes GameInterface.storage reads/writes (never breaks them).
 *   3. exposes window.__SF2LAN for the lobby UI + tooling.
 *   4. loads ./lan/lan.js once the game has booted.
 * ==========================================================================*/
(function () {
  'use strict';

  var MOD = '0.1.0';
  var PROTO = 1;

  // the script's own URL, captured SYNCHRONOUSLY (document.currentScript is
  // only set while a classic script executes - not in async callbacks)
  var THIS_URL = (function () {
    try {
      var cs = document.currentScript;
      if (cs && cs.src) return cs.src;
    } catch (e) { /* fall through */ }
    try {
      var ss = document.getElementsByTagName('script');
      for (var i = ss.length - 1; i >= 0; i--) {
        if (ss[i].src && ss[i].src.indexOf('lan-pre.js') >= 0) return ss[i].src;
      }
    } catch (e2) { /* fall through */ }
    return '';
  })();

  var api = (window.__SF2LAN = {
    mod: MOD,
    proto: PROTO,
    storageLog: [],
    storage: null,          // filled in by lan.js (codec helpers)
    ticks: 0,
    booted: false,
    hasFeature: function () { return false; },
    log: function () {
      try {
        var a = Array.prototype.slice.call(arguments);
        console.log.apply(console, ['%c[SF2LAN]', 'color:#7cf'].concat(a));
      } catch (e) { /* noop */ }
    }
  });

  function now() { try { return Date.now(); } catch (e) { return 0; } }

  /* ---------------------------------------------------------------- 1. features */
  function patchGameInterface() {
    var gi = window.GameInterface;
    if (!gi || !gi.hasFeature || gi.__sf2lan) return !!gi;
    gi.__sf2lan = true;

    var origHasFeature = gi.hasFeature.bind(gi);
    gi.hasFeature = function (f) {
      if (f === 'standalone') return true;   // -> offline mode, no portal, no Sentry
      if (f === 'rewarded') return false;    // no ads in the LAN build
      try { return !!origHasFeature(f); } catch (e) { return false; }
    };
    api.hasFeature = function (f) { try { return !!gi.hasFeature(f); } catch (e) { return false; }; };

    if (gi.storage) {
      ['getItem', 'setItem', 'removeItem'].forEach(function (m) {
        var orig = gi.storage[m];
        if (typeof orig !== 'function' || orig.__sf2lan) return;
        var wrapped = function (k, v) {
          var out = (m === 'setItem') ? orig.call(gi.storage, k, v) : orig.call(gi.storage, k, v);
          try {
            api.storageLog.push({ t: now(), op: m, key: k, len: (m === 'setItem' && v != null) ? String(v).length : null });
            if (api.storageLog.length > 500) api.storageLog.splice(0, 250);
          } catch (e) { /* noop */ }
          return out;
        };
        wrapped.__sf2lan = true;
        gi.storage[m] = wrapped;
      });
    }
    api.log('GameInterface patched -> standalone =', gi.hasFeature('standalone'));
    return true;
  }

  if (!patchGameInterface()) {
    var tries = 0;
    var iv = setInterval(function () {
      if (patchGameInterface() || ++tries > 300) clearInterval(iv);
    }, 10);
  }

  /* ------------------------------------------------- 2. frame counter (our own) */
  (function tickLoop() {
    api.ticks++;
    window.requestAnimationFrame(tickLoop);
  })();

  /* --------------------------------------------------------- 3. load lobby UI */
  var uiStarted = false;
  function startUI() {
    if (uiStarted) return;
    uiStarted = true;
    api.booted = true;
    // absolute URL from THIS script tag (captured synchronously at load):
    // robust wherever the game document lives
    var here = THIS_URL || location.href.replace(/\/[^\/]*(\?.*)?$/, '/') + 'lan/lan-pre.js';
    var base = here.slice(0, here.lastIndexOf('/') + 1);
    // NOTE: in Chromium, dynamic import() inside an external classic script
    // resolves the specifier against the *script file's own* URL (not the
    // document), hence the fetch of /lan/lan/lan.js. Build an absolute URL.
    import(base + 'lan.js').then(function (m) {
      api.log('lobby UI loaded, api v' + (m && m.VERSION ? m.VERSION : '?'));
      try { window.dispatchEvent(new CustomEvent('sf2lan:ready')); } catch (e) {}
    }).catch(function (e) {
      api.importError = String((e && (e.stack || e.message)) || e);
      api.log('FAILED to load lan.js:', api.importError);
    });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', startUI);
  else startUI();

  api.log('pre-boot shim active (mod ' + MOD + ', proto ' + PROTO + ')');
})();
