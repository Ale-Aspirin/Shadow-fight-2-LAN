#!/usr/bin/env node
/* SF2 LAN Duel Room - test runner (zero deps).
 * 1) codec: decode/encode round-trip on a real save fixture
 * 2) card extraction sanity + clone-and-rename opponent injection pipeline
 * 3) LAN protocol: two in-test clients through a real relay server process
 */
import fs from 'node:fs';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import * as C from '../overlay/sf2codec.mjs';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(HERE, '..', '..');
const MOD_VERSION = JSON.parse(fs.readFileSync(path.join(ROOT, 'mod', 'package.json'), 'utf8')).version;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
let failures = 0;
const ok = (name, cond, extra = '') => {
  console.log((cond ? '  PASS ' : '  FAIL ') + name + (extra ? '  <- ' + extra : ''));
  if (!cond) failures++;
};

/* ------------------------------------------------------------ 1) codec */
console.log('[1/3] codec (real save fixture)');
const fxDir = path.join(HERE, 'fixtures');
const raw = fs.readFileSync(path.join(fxDir, 'SF2User.b64'), 'utf8').trim();
const xml = C.decodeUsers(raw);
ok('decodeUsers yields XML', xml.includes('<') && xml.includes('Warriors'), xml.length + ' chars');
ok('decode strips game padding', !xml.includes('\0') && xml.trimEnd().endsWith('</Root>'), 'len=' + xml.length);
ok('decode honours LE length prefix', (() => {
  const bytes = C.b64ToBytes(raw);
  const le = (bytes[0] | (bytes[1] << 8) | (bytes[2] << 16) | (bytes[3] << 24)) >>> 0;
  return le === Buffer.byteLength(xml, 'utf8');
})(), 'header matches xml bytes');
const re = C.encodeUsers(xml);
ok('encode header is LE byte length', (() => {
  const b = C.b64ToBytes(re);
  const le = (b[0] | (b[1] << 8) | (b[2] << 16) | (b[3] << 24)) >>> 0;
  return le === b.length - 4 && C.decodeUsers(re) === xml;
})(), 'clean=' + re.length + ' orig=' + raw.length);
ok('selfTest stable', C.selfTest(raw).stable);
ok('packs XML parses', (() => { const t = C.parseXml(fs.readFileSync(path.join(fxDir, 'SF2Packs.xml'), 'utf8')); return t.children.length > 0; })());

/* ------------------------------------------------------------ 2) card + injection */
console.log('[2/3] fighter card + opponent injection');
const card = C.extractFighter(xml);
ok('card.ok', card.ok === true);
ok('card has name', typeof card.name === 'string' && card.name.length > 0, card.name);
ok('card has level', typeof card.level === 'number', String(card.level));
const friend = { name: 'LAN-Friend', level: 7, gear: card.gear, items: card.items, raw: card.raw };
const inj = C.injectOpponentIntoUsers(xml, friend);
ok('injection ok', inj.ok === true, inj.reason || '');
if (inj.ok) {
  const px = C.decodeUsers(C.encodeUsers(inj.xml));
  const after = C.warriorSpans(px);
  const before = C.warriorSpans(xml);
  ok('encodeUsers accepts patched XML', px === inj.xml);
  ok('warrior count +1', after.length === before.length + 1, before.length + ' -> ' + after.length);
  ok('injected name present', after.some((s) => s.attrs.Name === 'LAN-Friend' || s.attrs.FirstName === 'LAN-Friend'));
  const added = after.find((s) => s.attrs.FirstName === 'LAN-Friend');
  ok('injected FirstName set (game reads this)', !!added);
  ok('injected IsFake bot flag', added && String(added.attrs.IsFake) === 'True');
  ok('injected level copied', added && added.attrs.Level === '7', added ? added.attrs.Level : 'none');
  // Phase-2: gear copy + replace (no stacking)
  const geared = { name: 'Gear-Foe', level: 9, gear: { Weapon: 'KatanaX', Armor: 'ArmorX', Helm: 'HelmX', Ranged: 'BowX', Magic: 'FireX' }, raw: { ...card.raw, Weapon: 'KatanaX', Level: '9' } };
  const inj2 = C.injectOpponentIntoUsers(inj.xml, geared);
  ok('re-inject replaces old clone', inj2.ok && inj2.removed === 1, 'removed=' + (inj2.removed ?? '?'));
  if (inj2.ok) {
    const spans2 = C.warriorSpans(inj2.xml);
    ok('re-inject stays +1 (no stack)', spans2.length === before.length + 1, spans2.length + ' warriors');
    const g2 = spans2.find((s) => s.attrs.FirstName === 'Gear-Foe');
    ok('re-injected gear copied', !!g2 && g2.attrs.Weapon === 'KatanaX' && g2.attrs.Level === '9');
    ok('old clone gone', !spans2.some((s) => s.attrs.FirstName === 'LAN-Friend'));
    const clean = C.removeInjectedClones(inj2.xml);
    ok('removeInjectedClones restores count', clean.removed === 1 && C.warriorSpans(clean.xml).length === before.length);
  }
}
/* ------------------------------------------------------------ 3) LAN protocol */
console.log('[3/3] LAN protocol (real relay + 2 in-test clients)');
const TEST_STATIC = '127.0.0.1:18088', TEST_LAN = '127.0.0.1:18089';
const srv = spawn(process.execPath,
  [path.join(ROOT, 'mod', 'server', 'lan-server.mjs'), '--quiet', '--static', TEST_STATIC, '--lan', TEST_LAN],
  { cwd: ROOT, stdio: 'ignore' });
await sleep(900);

function client() {
  const ws = new WebSocket('ws://' + TEST_LAN + '/lan');
  const seen = [];
  const c = {
    seen, open: new Promise((res, rej) => { ws.onopen = res; ws.onerror = (e) => rej(e); }),
    send: (o) => ws.send(JSON.stringify(o)),
    waitFor: (pred, ms = 5000) => new Promise((res, rej) => {
      const hit = seen.find(pred);
      if (hit) return res(hit);
      const t0 = Date.now();
      const iv = setInterval(() => {
        const h = seen.find(pred);
        if (h) { clearInterval(iv); res(h); }
        else if (Date.now() - t0 > ms) { clearInterval(iv); rej(new Error('waitFor timeout')); }
      }, 30);
    }),
    close: () => ws.close()
  };
  ws.onmessage = (m) => { try { seen.push(JSON.parse(m.data)); } catch {} };
  return c;
}

try {
  const a = client(), b = client();
  await a.open; await b.open;
  a.send({ t: 'hello', nick: 'Alice', mod: MOD_VERSION, proto: 1, card: { name: 'ALICE' } });
  b.send({ t: 'hello', nick: 'Bob', mod: MOD_VERSION, proto: 1, card: { name: 'BOB' } });
  const wa = await a.waitFor((m) => m.t === 'welcome');
  ok('A welcomed with id', typeof wa.id === 'number', 'id=' + wa.id);
  const bothPresent = (m) => m.t === 'roster' && m.peers && m.peers.some((p) => p.nick === 'Alice') && m.peers.some((p) => p.nick === 'Bob');
  const rosterB = await b.waitFor(bothPresent, 6000);
  ok('roster sees both players', bothPresent(rosterB));
  const peers = rosterB.peers;
  const idA = peers.find((p) => p.nick === 'Alice').id, idB = peers.find((p) => p.nick === 'Bob').id;
  ok('cards exchanged', peers.every((p) => p.card && p.card.name));
  a.send({ t: 'chat', text: 'gl' });
  const chat = await b.waitFor((m) => m.t === 'chat' && m.text === 'gl');
  ok('chat relayed', chat.nick === 'Alice');
  a.send({ t: 'duel.req', to: idB, card: { name: 'ALICE' }, bestOf: 3 });
  const req = await b.waitFor((m) => m.t === 'duel.req');
  ok('duel.req relayed', req.from === idA && req.fromNick === 'Alice' && req.card && req.card.name === 'ALICE');
  b.send({ t: 'duel.ready', to: idA, card: { name: 'BOB' } });
  const ready = await a.waitFor((m) => m.t === 'duel.ready');
  ok('duel.ready relayed', ready.from === idB && ready.card && ready.card.name === 'BOB');
  b.send({ t: 'duel.accept', to: idA, startAt: Date.now() + 1000, startAtServer: Date.now() + 1000, round: 1, bestOf: 3, card: { name: 'BOB' } });
  const acc = await a.waitFor((m) => m.t === 'duel.accept');
  ok('duel.accept relayed', acc.round === 1 && acc.fromNick === 'Bob' && typeof acc.startAtServer === 'number');
  a.send({ t: 'duel.result', to: idB, win: true, round: 1 });
  const res = await b.waitFor((m) => m.t === 'duel.result');
  ok('duel.result relayed', res.win === true && res.round === 1);
  // decline path still relays
  a.send({ t: 'duel.req', to: idB, card: { name: 'ALICE' }, bestOf: 5 });
  const req2 = await b.waitFor((m) => m.t === 'duel.req' && m.bestOf === 5);
  ok('duel.req (rematch) relayed', req2.from === idA);
  b.send({ t: 'duel.decline', to: idA });
  const dec = await a.waitFor((m) => m.t === 'duel.decline');
  ok('duel.decline relayed', dec.from === idB);
  a.send({ t: 'duel.input', to: idB, seq: 1, round: 1, keys: ['KeyW', 'KeyK'], ts: Date.now() });
  const inp = await b.waitFor((m) => m.t === 'duel.input' && m.seq === 1);
  ok('duel.input relayed (10Hz live channel)', inp.from === idA && Array.isArray(inp.keys) && inp.keys.includes('KeyK'));
  b.send({ t: 'duel.input', to: idA, seq: 2, round: 1, keys: ['KeyA'], ts: Date.now() });
  const inp2 = await a.waitFor((m) => m.t === 'duel.input' && m.seq === 2);
  ok('duel.input bidir', inp2.from === idB);
  a.send({ t: 'ping', ts: 12345 });
  const pong = await a.waitFor((m) => m.t === 'pong' && m.ts === 12345);
  ok('ping/pong', typeof pong.now === 'number');
  // version mismatch is rejected
  const bad = client();
  await bad.open;
  bad.send({ t: 'hello', nick: 'Eve', mod: '9.9.9', proto: 1 });
  const rej = await bad.waitFor((m) => m.t === 'reject');
  ok('version mismatch rejected', /mismatch/i.test(rej.reason), rej.reason.slice(0, 70));
  a.close(); b.close(); bad.close();
} catch (e) {
  ok('protocol exchange completed', false, e.message);
}
srv.kill();

console.log(failures === 0 ? '\nALL TESTS PASSED' : '\n' + failures + ' TEST(S) FAILED');
process.exit(failures === 0 ? 0 : 1);

