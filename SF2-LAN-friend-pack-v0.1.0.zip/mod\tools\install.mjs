#!/usr/bin/env node
/**
 * SF2 LAN Duel Room - installer
 * Copies the Shadow Fight 2 (Microsoft Store / MSIX) web build into SF2-LAN\game
 * and applies the *only* two modifications we make, both inside our own copy:
 *   1. game\index.html  -> add <script src="./lan/lan-pre.js"> (runs before boot)
 *   2. game\famobi.json -> features.standalone = true, ads off
 * The Store package itself is only ever READ. sf2.js is never touched.
 *
 * Usage:  node mod\tools\install.mjs [--force] [--src "<path to www>"]
 */
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const HERE = path.dirname(fileURLToPath(import.meta.url));   // ...\SF2-LAN\mod\tools
const ROOT = path.resolve(HERE, '..', '..');                 // ...\SF2-LAN
const GAME = path.join(ROOT, 'game');
const OVERLAY = path.join(ROOT, 'mod', 'overlay');
const LAN_DST = path.join(GAME, 'lan');
const WINDOWS_APPS = process.env.SF2_WINDOWSAPPS || 'C:\\Program Files\\WindowsApps';
const FORCE = process.argv.includes('--force');
const srcArg = (() => {
  const i = process.argv.indexOf('--src');
  return i >= 0 ? process.argv[i + 1] : null;
})();

const log = (...a) => console.log('[install]', ...a);
const mb = (n) => (n / 1048576).toFixed(1) + ' MB';
const sha256 = (f) => crypto.createHash('sha256').update(fs.readFileSync(f)).digest('hex');

/** Ask Windows where the Store package lives. (The WindowsApps root is not listable
 *  by a normal user, so readdir on it fails with EPERM - Get-AppxPackage still works.) */
function installLocationViaAppx() {
  const scripts = [
    "(Get-AppxPackage -Name 'Famobi.ShadowFight2' | Select-Object -First 1).InstallLocation",
    "(Get-AppxPackage | Where-Object { $_.Name -like '*ShadowFight*' } | Select-Object -First 1).InstallLocation"
  ];
  for (const s of scripts) {
    try {
      const out = execFileSync('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', s],
        { encoding: 'utf8', timeout: 60000 }).trim();
      if (out && fs.existsSync(path.join(out, 'www', 'index.html'))) return out;
    } catch (e) { /* try the next query */ }
  }
  return null;
}

/** Locate the www\ folder of the installed Store package (read-only). */
function findSource() {
  if (srcArg) {
    if (!fs.existsSync(path.join(srcArg, 'index.html'))) throw new Error('--src has no index.html: ' + srcArg);
    return srcArg;
  }
  const viaAppx = installLocationViaAppx();
  if (viaAppx) {
    log('found installed package via Get-AppxPackage:', path.basename(viaAppx));
    return path.join(viaAppx, 'www');
  }
  if (!fs.existsSync(WINDOWS_APPS)) throw new Error('Cannot see ' + WINDOWS_APPS);
  let dirs;
  try {
    dirs = fs.readdirSync(WINDOWS_APPS, { withFileTypes: true });
  } catch (e) {
    throw new Error('Cannot list ' + WINDOWS_APPS + ' (' + e.code + '). Re-run elevated or pass --src "<C:\\Program Files\\WindowsApps\\...\\www>".');
  }
  const cands = dirs
    .filter((d) => d.isDirectory() && /^Famobi\.ShadowFight2_/i.test(d.name))
    .map((d) => {
      const p = path.join(WINDOWS_APPS, d.name);
      return { p, www: path.join(p, 'www'), ver: (d.name.match(/_(\d+\.\d+\.\d+\.\d+)_/) || [, '0'])[1] };
    })
    .filter((c) => fs.existsSync(path.join(c.www, 'index.html')))
    .sort((a, b) => a.ver.localeCompare(b.ver, undefined, { numeric: true }));
  if (!cands.length) throw new Error('No Famobi.ShadowFight2 package with www\\index.html found in ' + WINDOWS_APPS);
  return cands[cands.length - 1].www;
}

/** Copy everything that is missing (or everything with --force). */
function copyTree(src, dst) {
  let copied = 0, skipped = 0, total = 0;
  fs.mkdirSync(dst, { recursive: true });
  for (const e of fs.readdirSync(src, { withFileTypes: true })) {
    const s = path.join(src, e.name), d = path.join(dst, e.name);
    if (e.isDirectory()) {
      const r = copyTree(s, d); copied += r.copied; skipped += r.skipped; total += r.total;
    } else {
      total += 1;
      if (!FORCE && fs.existsSync(d) && fs.statSync(d).size === fs.statSync(s).size) { skipped++; continue; }
      fs.copyFileSync(s, d);
      copied++;
      if (copied % 400 === 0) log('  ...', copied, 'files copied');
    }
  }
  return { copied, skipped, total };
}
/** Patch our copy of index.html exactly once. */
function patchIndex() {
  const f = path.join(GAME, 'index.html');
  let html = fs.readFileSync(f, 'utf8');
  if (html.includes('./lan/lan-pre.js')) return 'already patched';
  const anchor = /[ \t]*<script src="\.\/windows-game-interface\.js"><\/script>\r?\n/;
  if (!anchor.test(html)) throw new Error('index.html: anchor <script src="./windows-game-interface.js"> not found - game build changed.');
  html = html.replace(anchor, (m) => m + '\t\t<script src="./lan/lan-pre.js"></script>\n');
  fs.writeFileSync(f, html, 'utf8');
  return 'inserted lan-pre.js before boot script';
}

/** Standalone + no-ads config for our copy (the game itself never reads famobi.json). */
function patchFamobi() {
  const f = path.join(GAME, 'famobi.json');
  if (!fs.existsSync(f)) return 'missing (skipped)';
  const cfg = JSON.parse(fs.readFileSync(f, 'utf8'));
  cfg.features = { ...(cfg.features || {}), standalone: true, rewarded: false, iap: false };
  cfg.ads = { enabled: false, interstitial: { enabled: false }, rewarded: { enabled: false }, banner: { enabled: false }, initial: { enabled: false } };
  fs.writeFileSync(f, JSON.stringify(cfg, null, 2), 'utf8');
  return 'features.standalone=true, ads off';
}

function copyOverlay() {
  fs.mkdirSync(LAN_DST, { recursive: true });
  let n = 0;
  for (const e of fs.readdirSync(OVERLAY, { withFileTypes: true })) {
    if (!e.isFile()) continue;
    fs.copyFileSync(path.join(OVERLAY, e.name), path.join(LAN_DST, e.name));
    n++;
  }
  return n + ' overlay files -> game\\lan\\';
}

function dirSize(p) {
  let s = 0;
  for (const e of fs.readdirSync(p, { withFileTypes: true })) {
    const q = path.join(p, e.name);
    s += e.isDirectory() ? dirSize(q) : (fs.statSync(q).size || 0);
  }
  return s;
}
// ---------------------------------------------------------------- main
log('project root     :', ROOT);
const SRC_WWW = findSource();
log('source (READ-ONLY):', SRC_WWW);
const pkgDir = path.dirname(SRC_WWW);
const pkgVersion = path.basename(pkgDir).split('_')[1] || 'unknown';

log('copying game files (first run: ~578 MB / 4.8k files, please wait)...');
const t0 = Date.now();
const r = copyTree(SRC_WWW, GAME);
log(`copy done: ${r.copied} copied, ${r.skipped} reused, ${r.total} files, ${((Date.now() - t0) / 1000).toFixed(1)}s`);

log('patch index.html  :', patchIndex());
log('patch famobi.json :', patchFamobi());
log('overlay           :', copyOverlay());

const build = {
  mod: JSON.parse(fs.readFileSync(path.join(ROOT, 'mod', 'package.json'), 'utf8')).version,
  sourcePackage: path.basename(pkgDir),
  sourcePackageVersion: pkgVersion,
  installedAt: new Date().toISOString(),
  bundles: Object.fromEntries(
    fs.readdirSync(GAME)
      .filter((f) => /^sf2\..*\.js$/.test(f) || f === 'windows-game-interface.js')
      .map((f) => [f, sha256(path.join(GAME, f))])
  ),
  note: 'Game bundles + all assets are byte-identical copies of the Store package. Only index.html + famobi.json are patched, plus game\\lan\\ is added.'
};
fs.writeFileSync(path.join(GAME, 'BUILD.json'), JSON.stringify(build, null, 2));

console.log('\n[install] done.');
console.log('  game folder      :', GAME, '(' + mb(dirSize(GAME)) + ')');
for (const [f, h] of Object.entries(build.bundles)) console.log('  ' + f.padEnd(24), 'sha256 ' + h.slice(0, 16) + '...');
console.log('  original package :', pkgDir, '<- never written to');
console.log('\nNext: double-click mod\\launcher\\Play.cmd\n');


