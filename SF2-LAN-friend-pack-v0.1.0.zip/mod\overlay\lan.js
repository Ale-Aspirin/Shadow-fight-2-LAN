/* ============================================================================
 * SF2 LAN Duel Room - overlay UI + LAN session logic
 * Loaded by lan-pre.js (dynamic import) inside the game page. Vanilla JS,
 * no dependencies, never patches the game engine - it talks to GameInterface,
 * to the save storage, and to the local relay server over WebSocket.
 * ==========================================================================*/
import * as C from './sf2codec.mjs';

export const VERSION = '0.1.0';
const PROTO = 1;

const LS_LAROOM = 'sf2lan.room';
const LS_NICK = 'sf2lan.nick';
const LS_BACKUP = 'sf2lan.saveBackup';

const state = {
  nick: localStorage.getItem(LS_NICK) || 'fighter-' + Math.floor(Math.random() * 900 + 100),
  ws: null,
  myId: null,
  host: '',
  peers: [],
  card: null,
  inFlight: null,
  duel: null,
  log: [],
  serverOffset: 0,
  rtt: null,
  inputSeq: 0,
  foeInput: null, // {keys, seq, at, rtt}
  score: { me: 0, them: 0 }
};

/* ------------------------------------------------------------------- styles */
const CSS = `
#sl-fab{position:fixed;right:14px;top:14px;z-index:2147483000;font:600 13px/1.2 Segoe UI,system-ui,sans-serif;
  background:linear-gradient(180deg,#2b3a55,#16202f);color:#eaf2ff;border:1px solid #4d6fa8;border-radius:10px;
  padding:9px 12px;cursor:pointer;box-shadow:0 6px 20px rgba(0,0,0,.5);display:flex;gap:8px;align-items:center}
#sl-fab:hover{border-color:#7fb0ff}
#sl-fab .dot{width:9px;height:9px;border-radius:50%;background:#666;box-shadow:0 0 6px #000}
#sl-fab.on .dot{background:#39d353;box-shadow:0 0 8px #39d353}
#sl-fab.duel .dot{background:#ff9f1a;box-shadow:0 0 8px #ff9f1a}
#sl-panel{position:fixed;right:14px;top:58px;width:372px;max-height:calc(100vh - 90px);z-index:2147483000;
  display:none;flex-direction:column;background:rgba(12,17,26,.96);color:#e8eef8;border:1px solid #33507d;
  border-radius:12px;box-shadow:0 18px 50px rgba(0,0,0,.65);font:13px/1.45 Segoe UI,system-ui,sans-serif;overflow:hidden}
#sl-panel.open{display:flex}
#sl-panel header{display:flex;align-items:center;gap:8px;padding:10px 12px;background:linear-gradient(180deg,#22314a,#151d2a);border-bottom:1px solid #2f4767}
#sl-panel header b{font-size:13px;letter-spacing:.4px}
#sl-panel header .sp{flex:1}
#sl-panel .x{cursor:pointer;opacity:.7;padding:2px 6px;border-radius:6px}
#sl-panel .x:hover{background:#2c3f5c;opacity:1}
#sl-body{padding:10px 12px;overflow:auto}
#sl-body h4{margin:12px 0 6px;font-size:11px;text-transform:uppercase;letter-spacing:.9px;color:#8fb0dd}
#sl-body h4:first-child{margin-top:0}
.sl-row{display:flex;gap:6px;align-items:center}
.sl-row>*{min-width:0}
input.sl,select.sl{flex:1;background:#0d141f;border:1px solid #33507d;color:#e8eef8;border-radius:8px;padding:7px 9px;font:inherit}
button.sl{background:linear-gradient(180deg,#2c4262,#1a2537);color:#eaf2ff;border:1px solid #456c9c;border-radius:8px;
  padding:7px 11px;font:600 12px inherit;cursor:pointer;white-space:nowrap}
button.sl:hover:not(:disabled){border-color:#7fb0ff;background:linear-gradient(180deg,#3a5784,#22314a)}
button.sl:disabled{opacity:.45;cursor:not-allowed}
button.sl.primary{background:linear-gradient(180deg,#2f7d4f,#1b4a30);border-color:#48a06a}
button.sl.danger{background:linear-gradient(180deg,#7d2f2f,#4a1b1b);border-color:#a04848}
.sl-peer{display:flex;align-items:center;gap:8px;padding:7px 9px;border:1px solid #26374f;border-radius:9px;margin-bottom:6px;background:#101827}
.sl-peer .grow{flex:1;min-width:0}
.sl-peer .nm{font-weight:600}
.sl-peer .sub{color:#8fb0dd;font-size:11px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.sl-chip{display:inline-block;background:#1b2740;border:1px solid #33507d;border-radius:20px;padding:1px 8px;font-size:11px;margin:2px 4px 0 0}
#sl-log{height:132px;overflow:auto;background:#0b1119;border:1px solid #26374f;border-radius:9px;padding:7px 9px;font-size:12px}
#sl-log div{margin-bottom:3px;word-wrap:break-word}
#sl-log .me{color:#8fe3a5}#sl-log .them{color:#ffd479}#sl-log .sys{color:#8fb0dd}#sl-log .err{color:#ff9c9c}
#sl-duel{margin-top:8px;padding:9px;border-radius:9px;background:#16203a;border:1px solid #38598f;display:none}
#sl-duel.open{display:block}
#sl-duel .big{font-size:15px;font-weight:700;text-align:center;margin:2px 0 6px}
#sl-card{background:#101827;border:1px solid #26374f;border-radius:9px;padding:8px 9px}
#sl-card .nm{font-weight:700}
#sl-card .sub{color:#8fb0dd;font-size:11px}
#sl-versus{display:none;margin-top:6px;padding:8px 9px;border-radius:9px;background:#141d33;border:1px solid #3a5a94;font-size:12px}
#sl-versus.open{display:block}
#sl-versus .vs{font-weight:800;text-align:center;color:#ffd479;letter-spacing:.6px;margin:2px 0 4px}
#sl-status{display:inline-block;min-width:10px;text-align:center;padding:1px 8px;border-radius:20px;font-size:11px;border:1px solid #33507d;background:#101827;color:#8fb0dd;margin-left:6px;vertical-align:middle}
#sl-status.ok{color:#8fe3a5;border-color:#48a06a}
#sl-status.err{color:#ff9c9c;border-color:#a04848}
#sl-live{margin-top:6px;padding:6px 8px;border-radius:8px;background:#0b1119;border:1px solid #26374f;font-size:11px;color:#8fb0dd;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
#sl-live b{color:#eaf2ff}
.sl-ver{color:#5f7695;font-size:11px;text-align:center;padding:8px 0 2px}
.sl-note{color:#93a7c4;font-size:11px;margin-top:6px}
.sl-err{color:#ff9c9c;font-size:12px;margin-top:6px}
.sl-ok{color:#8fe3a5;font-size:12px;margin-top:6px}
`;

function mountStyles() {
  const s = document.createElement('style');
  s.textContent = CSS;
  document.head.appendChild(s);
}
/* ------------------------------------------------------------------ DOM shell */
const el = (tag, props = {}, kids = []) => {
  const n = document.createElement(tag);
  for (const [k, v] of Object.entries(props)) {
    if (k === 'class') n.className = v;
    else if (k === 'html') n.innerHTML = v;
    else if (k === 'text') n.textContent = v;
    else if (k.startsWith('on') && typeof v === 'function') n.addEventListener(k.slice(2), v);
    else if (v != null) n.setAttribute(k, v);
  }
  for (const k of [].concat(kids)) n.appendChild(typeof k === 'string' ? document.createTextNode(k) : k);
  return n;
};
const $ = (sel) => document.querySelector(sel);
let ui = null;

function buildUI() {
  mountStyles();
  const row = (kids, style) => el('div', { class: 'sl-row', style: style || null }, kids);
  ui = {
    fab: el('div', { id: 'sl-fab', title: 'SF2 LAN Duel Room', onclick: togglePanel },
      [el('span', { class: 'dot' }), el('span', { text: 'LAN' })]),
    panel: el('div', { id: 'sl-panel' }, [
      el('header', {}, [el('b', { text: 'SF2 LAN Duel Room' }), el('span', { id: 'sl-status', text: 'offline' }), el('span', { class: 'sp' }),
      el('span', { class: 'x', text: '\u2715', onclick: togglePanel })]),
      el('div', { id: 'sl-body' }, [
        el('h4', { text: '1. Connect (same WiFi)' }),
        row([el('input', { class: 'sl', id: 'sl-nick', placeholder: 'your name', maxlength: '20' }),
        el('button', { class: 'sl', id: 'sl-setnick', text: 'Set name', onclick: saveNick })]),
        row([el('input', { class: 'sl', id: 'sl-host', placeholder: "friend's IP (host PC)" }),
        el('button', { class: 'sl primary', id: 'sl-join', text: 'Join', onclick: () => connect() })], 'margin-top:6px'),
        row([el('button', { class: 'sl', id: 'sl-hostbtn', text: 'I am the host', onclick: hostMode }),
        el('button', { class: 'sl danger', id: 'sl-disconnect', text: 'Leave', onclick: () => disconnect(), disabled: 'disabled' })], 'margin-top:6px'),
        row([el('button', { class: 'sl', id: 'sl-copyip', text: 'Copy my IP', onclick: copyMyIp }),
        el('button', { class: 'sl', id: 'sl-myip', text: 'Show my IP', onclick: showMyIp })], 'margin-top:6px'),
        el('div', { id: 'sl-conn', class: 'sl-note', text: 'Not connected. One PC presses "I am the host", the other types that IP and presses Join.' }),

        el('h4', { text: '2. Your fighter' }),
        el('div', { id: 'sl-card', html: '<div class="sub">reading save…</div>' }),
        el('div', { id: 'sl-versus' }),
        row([el('button', { class: 'sl', text: 'Re-read from game', onclick: () => refreshCard(true) })], 'margin-top:6px'),

        el('h4', { text: '3. Players in room' }),
        el('div', { id: 'sl-peers', class: 'sub', style: 'color:#8fb0dd', text: 'nobody yet' }),

        el('h4', { text: '4. Duel (same-time honor fight)' }),
        el('div', { id: 'sl-duel' }, [
          el('div', { class: 'big', id: 'sl-duel-title', text: 'idle' }),
          el('div', { id: 'sl-duel-sub', class: 'sub' }),
          row([el('button', { class: 'sl primary', id: 'sl-duel-go', text: 'Start round', onclick: duelStart }),
          el('button', { class: 'sl', id: 'sl-duel-win', text: 'I won', onclick: () => reportResult(true), disabled: 'disabled' }),
          el('button', { class: 'sl', id: 'sl-duel-lose', text: 'I lost', onclick: () => reportResult(false), disabled: 'disabled' })], 'margin-top:8px'),
          row([el('button', { class: 'sl', id: 'sl-duel-rematch', text: 'Rematch', onclick: rematch, disabled: 'disabled' }),
          el('button', { class: 'sl', id: 'sl-duel-cancel', text: 'Cancel', onclick: cancelDuel }),
          el('button', { class: 'sl', id: 'sl-duel-reset', text: 'Reset 0-0', onclick: resetScore })], 'margin-top:6px'),
          row([el('button', { class: 'sl', id: 'sl-inject', text: 'Put opponent in my game (beta)', onclick: injectOpponent, disabled: 'disabled' }),
          el('button', { class: 'sl', id: 'sl-revert', text: 'Revert save', onclick: revertSave, disabled: 'disabled' })], 'margin-top:6px'),
          el('div', { id: 'sl-live', text: 'live inputs: —' }),
          el('div', { class: 'sl-note', id: 'sl-mirror-row' }, [
            el('input', { type: 'checkbox', id: 'sl-mirror', style: 'vertical-align:middle', onchange: (e) => {
              state.mirrorFoe = !!(e.target && e.target.checked);
              if (!state.mirrorFoe) {
                for (const k of [...mirroredDown]) {
                  try { document.dispatchEvent(new KeyboardEvent('keyup', { code: k, bubbles: true })); } catch {}
                }
                mirroredDown.clear();
              }
              log(state.mirrorFoe ? 'MIRROR ON — foe keys will steer your fighter too (TEST, both steer ONE fighter)' : 'mirror off', state.mirrorFoe ? 'err' : 'sys');
              renderLive();
            } }),
            el('span', { text: ' Mirror foe inputs (TEST: both steer ONE fighter)' })
          ]),
          el('div', { id: 'sl-duel-msg', class: 'sl-note' })
        ]),

        el('h4', { text: 'Room chat' }),
        el('div', { id: 'sl-log' }),
        row([el('input', { class: 'sl', id: 'sl-chat', placeholder: 'message…', maxlength: '300', onkeydown: (e) => { if (e.key === 'Enter') sendChat(); } }),
        el('button', { class: 'sl', text: 'Send', onclick: sendChat })], 'margin-top:6px'),
        el('div', { class: 'sl-ver', id: 'sl-ver', text: 'mod v' + VERSION + ' · proto ' + PROTO })
      ])
    ])
  };
  document.body.appendChild(ui.fab);
  document.body.appendChild(ui.panel);
  // Cache button refs (avoids stale #sl-connect lookups that never existed).
  ui.joinBtn = $('#sl-join'); ui.hostBtn = $('#sl-hostbtn'); ui.discBtn = $('#sl-disconnect');
  ui.setNickBtn = $('#sl-setnick'); ui.status = $('#sl-status');
  $('#sl-nick').value = state.nick;
  setConnUI(false);
  refreshCard();
  setInterval(() => { if (state.ws && state.ws.readyState === 1) send({ t: 'ping', ts: Date.now() }); }, 5000);
}

function setConnUI(connected, label) {
  if (!ui) return;
  const st = ui.status || $('#sl-status');
  if (st) {
    st.textContent = label || (connected ? 'online' : 'offline');
    st.className = connected ? 'ok' : '';
    st.id = 'sl-status';
  }
  if (ui.joinBtn) ui.joinBtn.disabled = !!connected;
  if (ui.hostBtn) ui.hostBtn.disabled = !!connected;
  if (ui.discBtn) ui.discBtn.disabled = !connected;
  if (ui.fab) ui.fab.classList.toggle('on', !!connected);
}

function togglePanel() { ui.panel.classList.toggle('open'); }

function log(text, kind = 'sys') {
  state.log.push({ text, kind });
  const box = ui && $('#sl-log');
  if (box) {
    box.appendChild(el('div', { class: kind, text }));
    box.scrollTop = box.scrollHeight;
  }
  const g = window.__SF2LAN && window.__SF2LAN.log;
  if (g) g(text);
}
const sys = (t) => log(t, 'sys');
/* ------------------------------------------------------- storage + fighter */
const gi = () => window.GameInterface;
function readKey(key) {
  try {
    const v = gi().storage.getItem(key);
    return v == null ? null : String(v);
  } catch (e) { log('storage read failed (' + key + '): ' + e.message, 'err'); return null; }
}
function writeKey(key, value) {
  try { gi().storage.setItem(key, value); return true; }
  catch (e) { log('storage write failed (' + key + '): ' + e.message, 'err'); return false; }
}

function readCard() {
  const raw = readKey(C.KEYS.users);
  if (!raw) return { ok: false, reason: 'no save found (SF2User empty) - play the game once, then press "Re-read from game"' };
  let xml;
  try { xml = C.decodeUsers(raw); } catch (e) { return { ok: false, reason: 'decode failed: ' + e.message }; }
  try {
    const card = C.extractFighter(xml);
    card.blobLen = raw.length;
    card.xmlLen = xml.length;
    card.ok = card.ok !== false;
    return card;
  } catch (e) { return { ok: false, reason: 'parse failed: ' + e.message }; }
}

function refreshCard(announce) {
  const card = readCard();
  if (card.ok) state.card = card;
  const box = $('#sl-card');
  if (!box) return card;
  box.innerHTML = '';
  if (!card.ok) {
    box.appendChild(el('div', { class: 'sub', text: 'not available: ' + card.reason }));
    if (announce) log('card: ' + card.reason, 'err');
    return card;
  }
  box.appendChild(el('div', { class: 'nm', text: card.name + (card.level != null ? '  ·  level ' + card.level : '') }));
  const gs = Object.entries(card.gear).map(([k, v]) => k + '=' + v).join('  ·  ');
  if (gs) box.appendChild(el('div', { class: 'sub', text: gs }));
  const row = el('div', {});
  for (const it of (card.items || []).slice(0, 8)) row.appendChild(el('span', { class: 'sl-chip', text: it.slot + (it.name ? ': ' + it.name : '') }));
  box.appendChild(row);
  box.appendChild(el('div', { class: 'sub', style: 'margin-top:5px', text: (card.items || []).length + ' item nodes · ' + card.warriorCount + ' warriors in save' }));
  if (announce) log('card re-read: ' + card.name + ' (level ' + card.level + ')', 'ok');
  if (state.ws && state.ws.readyState === 1) send({ t: 'card', card: publicCard(card) });
  return card;
}
const publicCard = (c) => ({ name: c.name, level: c.level, gear: c.gear, items: (c.items || []).slice(0, 8), raw: c.raw });

/* --------------------------------------------------- save backup / revert */
function backupSave() {
  const users = readKey(C.KEYS.users), packs = readKey(C.KEYS.packs);
  if (!users) return false;
  try {
    localStorage.setItem(LS_BACKUP, JSON.stringify({ users, packs, at: Date.now() }));
    log('save backed up (' + users.length + ' B users, ' + (packs ? packs.length : 0) + ' B packs)', 'ok');
    $('#sl-revert').disabled = false;
    return true;
  } catch (e) { log('backup failed: ' + e.message, 'err'); return false; }
}
function revertSave() {
  const raw = localStorage.getItem(LS_BACKUP);
  if (!raw) { log('nothing to revert', 'err'); return; }
  const b = JSON.parse(raw);
  writeKey(C.KEYS.users, b.users);
  if (b.packs) writeKey(C.KEYS.packs, b.packs);
  log('save reverted to the pre-injection backup. Reload the game (F5 is disabled in app mode - just restart Play.cmd).', 'ok');
}
/* ------------------------------------------------------------------ network */
const WS_PORT = 8789;
function send(obj) {
  if (state.ws && state.ws.readyState === 1) state.ws.send(JSON.stringify(obj));
}
const firstIp = (s) => String(s || '').trim().replace(/^wss?:\/\//, '').replace(/\/.*$/, '').split(':')[0];

function connect(target) {
  const hostInput = $('#sl-host');
  const host = firstIp(target == null ? (hostInput ? hostInput.value : '') : target);
  if (!host) { log('type the host IP first', 'err'); setConnUI(false, 'no IP'); return; }
  disconnect(true);
  state.host = host;
  try { localStorage.setItem(LS_LAROOM, host); } catch {}
  setConnUI(false, 'connecting…');
  const connBox = $('#sl-conn');
  if (connBox) connBox.textContent = 'connecting to ' + host + ':' + WS_PORT + ' … (check firewall if this hangs)';
  log('connecting to ws://' + host + ':' + WS_PORT + '/lan ...', 'sys');
  let ws;
  try { ws = new WebSocket('ws://' + host + ':' + WS_PORT + '/lan'); }
  catch (e) { log('bad address: ' + e.message, 'err'); setConnUI(false, 'bad IP'); return; }
  state.ws = ws;
  ws.onopen = () => {
    setConnUI(true, 'online');
    if (connBox) connBox.textContent = 'connected, joining as ' + state.nick + ' …';
    send({ t: 'hello', nick: state.nick, mod: VERSION, proto: PROTO, card: state.card ? publicCard(state.card) : null });
  };
  ws.onmessage = (m) => { try { handle(JSON.parse(m.data)); } catch (e) { log('bad message: ' + e.message, 'err'); } };
  ws.onclose = () => {
    state.ws = null; state.myId = null; state.peers = [];
    setConnUI(false, 'offline');
    renderPeers(); renderVersus();
    log('disconnected', 'sys');
    if (connBox) connBox.textContent = 'Not connected. One PC presses "I am the host", the other types that IP and presses Join.';
  };
  ws.onerror = () => { log('could not reach ' + host + ':' + WS_PORT + ' (firewall? wrong IP? host not hosting?)', 'err'); setConnUI(false, 'unreachable'); };
}

function disconnect(silent) {
  try { releaseMirror(); } catch {}
  if (state.ws) { try { state.ws.close(); } catch {} state.ws = null; }
  state.myId = null; state.peers = []; state.duel = null;
  setConnUI(false, 'offline');
  renderPeers(); renderDuel(); renderVersus();
  if (!silent) log('left the room', 'sys');
}

function saveNick() {
  const v = ($('#sl-nick').value || '').trim().slice(0, 20) || state.nick;
  state.nick = v;
  localStorage.setItem(LS_NICK, v);
  if (state.ws && state.ws.readyState === 1) { send({ t: 'hello', nick: v, mod: VERSION, proto: PROTO, card: state.card ? publicCard(state.card) : null }); }
  log('name set to ' + v, 'ok');
}

let cachedAddrs = [];
function fetchAddrs(cb) {
  try {
    const ws = new WebSocket('ws://127.0.0.1:' + WS_PORT + '/lan');
    const done = (v) => { try { ws.close(); } catch {} if (cb) cb(v); };
    const timer = setTimeout(() => done(null), 4000);
    ws.onmessage = (m) => {
      let msg = null;
      try { msg = JSON.parse(m.data); } catch { return; }
      if (msg.t === 'hello?') ws.send(JSON.stringify({ t: 'hello', nick: '__probe__', mod: VERSION, proto: PROTO }));
      if (msg.t === 'welcome') {
        clearTimeout(timer);
        cachedAddrs = msg.addresses || [];
        const hostInput = $('#sl-host');
        if (hostInput && !hostInput.value && cachedAddrs[0]) hostInput.value = cachedAddrs[0].address;
        done(cachedAddrs);
      }
    };
    ws.onerror = () => { clearTimeout(timer); log('relay not running on this PC - start it with Play.cmd', 'err'); if (cb) cb(null); };
  } catch (e) { log('host probe failed: ' + e.message, 'err'); if (cb) cb(null); }
}

function showMyIp() {
  fetchAddrs((addrs) => {
    if (!addrs || !addrs.length) { log('no LAN IPv4 found - are you on WiFi?', 'err'); return; }
    const ips = addrs.map((a) => a.address + '  (' + a.name + ')').join('\n     ');
    log('your LAN IPs:\n     ' + ips + '\nShare one with your friend.', 'ok');
    const connBox = $('#sl-conn');
    if (connBox) connBox.textContent = 'your IP: ' + addrs[0].address + ' — friend types this + Join';
  });
}

function copyMyIp() {
  const doCopy = (text) => {
    try {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(text).then(() => log('copied IP ' + text + ' — send it to your friend', 'ok'), () => log('copy blocked, IP is ' + text, 'err'));
      } else {
        const ta = document.createElement('textarea');
        ta.value = text; document.body.appendChild(ta); ta.select();
        document.execCommand('copy'); ta.remove();
        log('copied IP ' + text, 'ok');
      }
    } catch (e) { log('copy failed, IP is ' + text, 'err'); }
  };
  if (cachedAddrs.length) doCopy(cachedAddrs[0].address);
  else fetchAddrs((addrs) => { if (addrs && addrs[0]) doCopy(addrs[0].address); });
}

function hostMode() {
  log('you are the host. Your friend types one of these IPs:', 'sys');
  showMyIp();
  connect('127.0.0.1');
}

function renderPeers() {
  const box = ui && $('#sl-peers');
  if (!box) { renderVersus(); return; }
  box.innerHTML = '';
  const others = state.peers.filter((p) => p.id !== state.myId);
  if (!others.length) { box.appendChild(el('div', { class: 'sub', text: state.ws ? 'only you so far - ask your friend to Join' : 'not connected' })); renderVersus(); return; }
  for (const p of others) {
    const c = p.card || {};
    const info = (c.name || p.nick) + (c.level != null ? ' · lvl ' + c.level : '') + (c.gear && c.gear.Weapon ? ' · ' + c.gear.Weapon : '');
    box.appendChild(el('div', { class: 'sl-peer' }, [
      el('div', { class: 'grow' }, [el('div', { class: 'nm', text: p.nick }), el('div', { class: 'sub', text: info })]),
      el('button', { class: 'sl primary', text: 'Duel', onclick: () => duelChallenge(p.id) })
    ]));
  }
  renderVersus();
}

function fmtCardLine(card, fallbackNick) {
  if (!card) return (fallbackNick || '???') + ' · no card yet (ask them to Re-read)';
  const bits = [card.name || fallbackNick || 'fighter'];
  if (card.level != null) bits.push('lvl ' + card.level);
  if (card.gear && card.gear.Weapon) bits.push(card.gear.Weapon);
  return bits.join(' · ');
}

function renderVersus() {
  const box = $('#sl-versus');
  if (!box) return;
  box.innerHTML = '';
  box.classList.remove('open');
  const others = (state.peers || []).filter((p) => p.id !== state.myId);
  if (!state.ws || !others.length) return;
  const opp = others[0];
  const me = state.card && state.card.ok !== false ? state.card : null;
  box.classList.add('open');
  box.appendChild(el('div', { class: 'sub', text: 'next duel' }));
  box.appendChild(el('div', { text: 'YOU: ' + (me ? fmtCardLine(publicCard(me), state.nick) : state.nick + ' · press Re-read') }));
  box.appendChild(el('div', { class: 'vs', text: 'VS  (+' + (others.length - 1) + ' waiting)' .replace(' (+0 waiting)', '') }));
  box.appendChild(el('div', { text: 'FOE: ' + fmtCardLine(opp.card, opp.nick) }));
}

function sendChat() {
  const inp = $('#sl-chat');
  const text = (inp.value || '').trim();
  if (!text || !state.ws) return;
  inp.value = '';
  send({ t: 'chat', text });
}

function handle(msg) {
  switch (msg.t) {
    case 'hello?':
      send({ t: 'hello', nick: state.nick, mod: VERSION, proto: PROTO, card: state.card ? publicCard(state.card) : null });
      return;
    case 'welcome':
      state.myId = msg.id;
      state.peers = (msg.peers || []).filter((p) => !String(p.nick || '').startsWith('__probe__'));
      setConnUI(true, 'online');
      $('#sl-conn').textContent = 'connected to ' + state.host + ' as ' + state.nick + ' (#' + msg.id + ')';
      log('joined the room as #' + msg.id, 'ok');
      // Push our (possibly freshly read) card so the foe sees a real VS line.
      refreshCard(false);
      renderPeers();
      return;
    case 'reject':
      log(msg.reason, 'err');
      alert(msg.reason);
      return;
    case 'roster':
      state.peers = (msg.peers || []).filter((p) => !String(p.nick || '').startsWith('__probe__'));
      renderPeers();
      return;
    case 'join':
      if (String(msg.nick || '').startsWith('__probe__')) return;
      log(msg.nick + ' joined (#' + msg.id + ')', 'them');
      return;
    case 'left':
      if (String(msg.nick || '').startsWith('__probe__')) return;
      log(msg.nick + ' left', 'them');
      if (state.duel && state.duel.peer === msg.id) { clearDuelTimers(state.duel); state.duel = null; renderDuel(); }
      renderVersus();
      return;
    case 'chat':
      log((msg.from === state.myId ? 'you: ' : msg.nick + ': ') + msg.text, msg.from === state.myId ? 'me' : 'them');
      return;
    case 'pong': {
      const rtt = Date.now() - msg.ts;
      state.rtt = rtt;
      // NTP-style offset: serverNow ≈ clientNow + offset.
      if (typeof msg.now === 'number' && typeof msg.ts === 'number') {
        const inst = ((msg.now - msg.ts) + (msg.now - Date.now())) / 2;
        state.serverOffset = state.serverOffset == null ? inst : state.serverOffset * 0.8 + inst * 0.2;
      }
      const n = $('#sl-conn');
      if (n && state.myId) n.textContent = 'connected to ' + state.host + ' as ' + state.nick + ' (#' + state.myId + ', ' + rtt + ' ms)';
      renderLive();
      return;
    }
    case 'error':
      log('peer error: ' + msg.reason, 'err');
      return;
    default:
      if (String(msg.t).startsWith('duel.')) return onDuel(msg);
      return;
  }
}
/* ------------------------------------------------- Phase 4b: live input channel */
const FIGHT_KEYS = new Set(['KeyW', 'KeyA', 'KeyS', 'KeyD', 'KeyJ', 'KeyK', 'KeyL', 'KeyO', 'KeyP', 'KeyU', 'KeyI', 'Space', 'ShiftLeft', 'ShiftRight', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight']);
const pressedKeys = new Set();
const mirroredDown = new Set(); // keys we injected for the foe (need keyup later)
try {
  window.addEventListener('keydown', (e) => {
    if (e.isTrusted === false) return; // ignore our own mirror injections (no echo)
    if (e.code && FIGHT_KEYS.has(e.code)) pressedKeys.add(e.code);
  }, { passive: true });
  window.addEventListener('keyup', (e) => {
    if (e.isTrusted === false) return;
    if (e.code) pressedKeys.delete(e.code);
  }, { passive: true });
  window.addEventListener('blur', () => pressedKeys.clear());
} catch {}
function shortKeys(keys) {
  return (keys || []).map((k) => k.replace(/^Key/, '').replace(/^Arrow/, '→').replace(/^Space$/, 'SPC')).join(' ').slice(0, 40) || '—';
}
function renderLive() {
  const box = $('#sl-live');
  if (!box) return;
  const d = state.duel;
  if (!d || (d.stage !== 'count' && d.stage !== 'fight')) {
    box.textContent = state.ws ? 'live inputs: idle (start a duel to stream 10Hz)' : 'live inputs: —';
    return;
  }
  const mine = shortKeys([...pressedKeys].slice(0, 8));
  const foe = state.foeInput ? shortKeys(state.foeInput.keys) : '—';
  const age = state.foeInput ? Math.max(0, Date.now() - state.foeInput.at) : null;
  const rtt = state.rtt != null ? state.rtt + 'ms' : '?';
  const mirroring = state.mirrorFoe && d.stage === 'fight' ? ' · MIRROR ON' : '';
  box.innerHTML = '';
  box.appendChild(el('span', {}, [
    'you: ', el('b', { text: mine }), '  ·  foe' + (age != null ? ' (' + age + 'ms ago)' : '') + ': ', el('b', { text: foe }),
    '  ·  net ' + rtt + '  ·  #' + (state.inputSeq || 0) + mirroring
  ]));
}

/* Mirror foe keys into the local fight (SAME-FIGHTER proof only).
 * Both PCs steer ONE local fighter — proves the 10Hz link can drive the
 * engine. True versus (foe drives P2/AI slot) needs the Hc hook from
 * REALTIME-FINDINGS.md and stays experimental. Never runs unless the
 * checkbox is on AND stage is fight AND foe packet is fresh. */
function mirrorFoeInputs() {
  const d = state.duel;  if (!d || d.stage !== 'fight' || !state.mirrorFoe || !state.foeInput) return;
  if (Date.now() - state.foeInput.at > 500) return; // stale: let keys drain
  const want = new Set((state.foeInput.keys || []).filter((k) => FIGHT_KEYS.has(k)).slice(0, 8));
  for (const k of [...mirroredDown]) {
    if (!want.has(k)) {
      try { document.dispatchEvent(new KeyboardEvent('keyup', { code: k, bubbles: true, cancelable: true })); } catch {}
      mirroredDown.delete(k);
    }
  }
  for (const k of want) {
    if (!mirroredDown.has(k) && !pressedKeys.has(k)) {
      try { document.dispatchEvent(new KeyboardEvent('keydown', { code: k, bubbles: true, cancelable: true })); } catch {}
      mirroredDown.add(k);
    }
  }
}
function releaseMirror() {
  for (const k of [...mirroredDown]) {
    try { document.dispatchEvent(new KeyboardEvent('keyup', { code: k, bubbles: true, cancelable: true })); } catch {}
  }
  mirroredDown.clear();
}
setInterval(() => {
  try {
    renderLive();
    const active = state.ws && state.ws.readyState === 1 && state.duel &&
      (state.duel.stage === 'count' || state.duel.stage === 'fight');
    if (!active || !state.mirrorFoe) releaseMirror();
    if (!active) return;
    state.inputSeq = (state.inputSeq || 0) + 1;
    send({ t: 'duel.input', to: state.duel.peer, seq: state.inputSeq, round: state.duel.round || 1, keys: [...pressedKeys].slice(0, 8), ts: Date.now() });
  } catch {}
}, 100);
/* --------------------------------------------------------------- duel flow */
const DUEL_REQ_TIMEOUT_MS = 30000;
const DUEL_RESULT_TIMEOUT_MS = 15000;
const DUEL_COUNTDOWN_MS = 7000;

function clearDuelTimers(d) {
  if (!d) return;
  if (d.reqTimer) { clearTimeout(d.reqTimer); d.reqTimer = null; }
  if (d.resultTimer) { clearTimeout(d.resultTimer); d.resultTimer = null; }
}

function renderDuel() {
  const box = ui && $('#sl-duel');
  if (!box) return;
  const d = state.duel;
  box.classList.toggle('open', !!d);
  if (!d) return;
  const t = $('#sl-duel-title'), s = $('#sl-duel-sub');
  const score = (state.score ? state.score.me : 0) + ' - ' + (state.score ? state.score.them : 0);
  const names = {
    req: 'challenge sent - waiting…', inc: 'incoming challenge - check popup',
    ready: 'both ready - press Start round', count: 'GET READY', fight: 'FIGHT!',
    done: d.disputed ? 'disputed - replay!' : 'round done', cancelled: 'cancelled'
  };
  t.textContent = (names[d.stage] || d.stage) + '   ' + score + (d.round ? '   R' + d.round : '');
  const foeBits = (d.peerNick || ('#' + d.peer)) + (d.peerCard ? ' · ' + (d.peerCard.name || '') + (d.peerCard.level != null ? ' (lvl ' + d.peerCard.level + ')' : '') : ' · no card yet');
  if (d.stage === 'count' || d.stage === 'fight' || d.stage === 'done') {
    // sub-line is owned by countdown/result text; keep foe line in title only
  } else {
    s.textContent = 'opponent: ' + foeBits + (d.stage === 'req' ? ' — waiting for accept (30s)…' : d.stage === 'ready' ? ' — challenger presses Start round' : '');
  }
  const fighting = d.stage === 'fight';
  const canStart = d.stage === 'ready';
  const done = d.stage === 'done';
  const goBtn = $('#sl-duel-go'), winBtn = $('#sl-duel-win'), loseBtn = $('#sl-duel-lose');
  const remBtn = $('#sl-duel-rematch'), cancelBtn = $('#sl-duel-cancel');
  if (goBtn) goBtn.disabled = !canStart;
  if (winBtn) winBtn.disabled = !fighting;
  if (loseBtn) loseBtn.disabled = !fighting;
  if (remBtn) remBtn.disabled = !done;
  if (cancelBtn) cancelBtn.disabled = !(d.stage === 'req' || d.stage === 'inc' || d.stage === 'ready');
  const injBtn = $('#sl-inject');
  if (injBtn) injBtn.disabled = !(d.peerCard);
}

function duelChallenge(peerId, keepScore) {
  const p = state.peers.find((x) => x.id === peerId);
  if (state.duel) clearDuelTimers(state.duel);
  state.duel = {
    peer: peerId, peerNick: p ? p.nick : '#' + peerId, peerCard: p ? p.card : null,
    stage: 'req', round: (state.duel && keepScore && state.duel.round) || 1, bestOf: 3,
    myResult: null, foeResult: null, disputed: false
  };
  if (!keepScore) state.score = state.score || { me: 0, them: 0 };
  send({ t: 'duel.req', to: peerId, card: state.card ? publicCard(state.card) : null, bestOf: 3 });
  log('challenge sent to ' + state.duel.peerNick + ' — waiting for accept…', 'me');
  state.duel.reqTimer = setTimeout(() => {
    if (state.duel && state.duel.stage === 'req') {
      log('no answer from ' + state.duel.peerNick + ' (30s) — challenge cancelled', 'err');
      state.duel.stage = 'cancelled'; renderDuel();
      setTimeout(() => { if (state.duel && state.duel.stage === 'cancelled') { state.duel = null; renderDuel(); } }, 4000);
    }
  }, DUEL_REQ_TIMEOUT_MS);
  renderDuel();
}

function rematch() {
  if (!state.duel || !state.duel.peer) return;
  const peer = state.duel.peer;
  log('rematch requested vs ' + (state.duel.peerNick || peer), 'me');
  duelChallenge(peer, true);
}

function resetScore() {
  state.score = { me: 0, them: 0 };
  log('series reset to 0-0', 'sys');
  renderDuel(); renderVersus();
}

function cancelDuel(notify) {
  if (!state.duel) return;
  clearDuelTimers(state.duel);
  if (notify !== false && state.ws && state.duel.peer != null && (state.duel.stage === 'req' || state.duel.stage === 'ready')) {
    send({ t: 'duel.decline', to: state.duel.peer });
  }
  log('duel cancelled', 'sys');
  state.duel = null; renderDuel();
}

function serverNow() { return Date.now() + (state.serverOffset || 0); }

function duelStart() {
  if (!state.duel || !state.ws || state.duel.stage !== 'ready') return;
  const round = (state.duel.round || 0) + 1;
  state.duel.round = round;
  state.duel.myResult = null; state.duel.foeResult = null; state.duel.disputed = false;
  // Common-clock start: prefer server time so both PCs count down together.
  const delay = DUEL_COUNTDOWN_MS;
  const startLocal = Date.now() + delay;
  const startAtServer = serverNow() + delay;
  send({ t: 'duel.accept', to: state.duel.peer, startAtServer, startAt: startLocal, round, bestOf: state.duel.bestOf || 3, card: state.card ? publicCard(state.card) : null, seed: (Math.floor(Math.random() * 2000000000) + Date.now() % 100000) % 2147483647 });
  beginCountdown(startLocal, 'challenger');
}

function beginCountdown(startAtLocal, role) {
  state.duel.stage = 'count';
  state.foeInput = null;
  renderDuel(); renderLive();
  const tick = () => {
    if (!state.duel || state.duel.stage !== 'count') return;
    const left = startAtLocal - Date.now();
    if (left > 0) {
      const n = $('#sl-duel-sub');
      if (n) n.textContent = 'starting in ' + Math.ceil(left / 1000) + 's - in the game, open the fight you agreed on (R' + (state.duel.round || 1) + ')';
      setTimeout(tick, 200);
      return;
    }
    state.duel.stage = 'fight';
    renderDuel();
    const sub = $('#sl-duel-sub');
    if (sub) sub.textContent = 'FIGHT! (R' + (state.duel.round || 1) + ') — then press I won / I lost';
    log('GO! Fight now (R' + (state.duel.round || 1) + '), then press "I won" / "I lost".', 'me');
  };
  tick();
}

function onDuel(msg) {
  switch (msg.t) {
    case 'duel.req': {
      if (state.duel && (state.duel.stage === 'fight' || state.duel.stage === 'count')) {
        send({ t: 'duel.decline', to: msg.from, busy: true });
        log(msg.fromNick + ' challenged you but you are mid-fight — auto-declined (busy)', 'err');
        return;
      }
      const ok = confirm('LAN duel request from ' + msg.fromNick + ' (best of ' + (msg.bestOf || 3) + '). Accept?');
      if (!ok) { send({ t: 'duel.decline', to: msg.from }); return; }
      if (state.duel) clearDuelTimers(state.duel);
      state.duel = { peer: msg.from, peerNick: msg.fromNick, peerCard: msg.card || null, stage: 'ready', round: state.duel && state.duel.round ? state.duel.round : 0, bestOf: msg.bestOf || 3, myResult: null, foeResult: null, disputed: false };
      state.score = state.score || { me: 0, them: 0 };
      send({ t: 'duel.ready', to: msg.from, card: state.card ? publicCard(state.card) : null });
      log(msg.fromNick + ' challenged you - accepted, waiting for them to press Start round', 'them');
      renderDuel(); renderVersus();
      return;
    }
    case 'duel.decline':
      if (!state.duel || state.duel.peer !== msg.from) return;
      clearDuelTimers(state.duel);
      log(msg.fromNick + (msg.busy ? ' is busy (mid-fight)' : ' declined') + ' — challenge over', 'them');
      state.duel = null; renderDuel(); return;
    case 'duel.ready':
      if (!state.duel || state.duel.peer !== msg.from) return;
      clearDuelTimers(state.duel);
      state.duel.peerCard = msg.card || state.duel.peerCard;
      state.duel.stage = 'ready';
      log(state.duel.peerNick + ' is ready — press Start round!', 'ok');
      renderDuel(); renderVersus();
      return;
    case 'duel.accept': {
      if (!state.duel) return;
      state.duel.peerCard = msg.card || state.duel.peerCard;
      state.duel.round = msg.round || (state.duel.round || 0) + 1;
      state.duel.bestOf = msg.bestOf || state.duel.bestOf || 3;
      state.duel.seed = msg.seed ?? null;
      state.duel.myResult = null; state.duel.foeResult = null; state.duel.disputed = false;
      state.foeInput = null;
      // Prefer server-clock start; fall back to legacy local startAt.
      const startLocal = typeof msg.startAtServer === 'number' && state.serverOffset != null
        ? msg.startAtServer - state.serverOffset
        : (msg.startAt || (Date.now() + DUEL_COUNTDOWN_MS));
      if (msg.seed != null) log('shared round seed: ' + msg.seed + ' (display only — engine still uses local RNG)', 'sys');
      beginCountdown(startLocal, 'acceptor');
      return;
    }
    case 'duel.input': {
      if (!state.duel || state.duel.peer !== msg.from) return;
      if (state.duel.stage !== 'count' && state.duel.stage !== 'fight') return;
      state.foeInput = { keys: Array.isArray(msg.keys) ? msg.keys.slice(0, 8) : [], seq: msg.seq || 0, at: Date.now() };
      renderLive();
      mirrorFoeInputs();
      return;
    }
    case 'duel.result': {
      if (!state.duel || state.duel.peer !== msg.from) return;
      state.duel.foeResult = !!msg.win;
      state.duel.foeRound = msg.round || state.duel.round;
      settleDuelIfReady('foe');
      return;
    }
    default: return;
  }
}

function settleDuelIfReady(who) {
  const d = state.duel;
  if (!d || d.stage !== 'fight') return;
  if (d.myResult == null || d.foeResult == null) {
    // Wait for the other side, but don't hang forever: score unconfirmed claim.
    if (d.myResult != null && !d.resultTimer) {
      d.resultTimer = setTimeout(() => {
        if (state.duel === d && d.stage === 'fight' && d.foeResult == null) {
          state.score = state.score || { me: 0, them: 0 };
          if (d.myResult) state.score.me++; else state.score.them++;
          d.stage = 'done'; d.disputed = false; d.unconfirmed = true;
          log('foe did not report within 15s — scored your claim (' + (d.myResult ? 'win' : 'loss') + ') as unconfirmed  ->  ' + state.score.me + '-' + state.score.them, 'err');
          renderDuel();
        }
      }, DUEL_RESULT_TIMEOUT_MS);
    }
    const sub = $('#sl-duel-sub');
    if (sub) sub.textContent = 'you reported ' + (d.myResult ? 'WIN' : 'LOSS') + ' — waiting for foe…';
    renderDuel();
    return;
  }
  if (d.resultTimer) { clearTimeout(d.resultTimer); d.resultTimer = null; }
  state.score = state.score || { me: 0, them: 0 };
  // Consistent iff exactly one side claims win.
  if (d.myResult !== d.foeResult) {
    if (d.myResult) state.score.me++; else state.score.them++;
    d.stage = 'done'; d.disputed = false;
    log('round confirmed: you ' + (d.myResult ? 'WON' : 'LOST') + '  ->  series ' + state.score.me + '-' + state.score.them, d.myResult ? 'me' : 'them');
  } else {
    d.stage = 'done'; d.disputed = true;
    log('DISPUTE: both reported ' + (d.myResult ? 'WIN' : 'LOSS') + ' — no point, replay the round (Rematch keeps score)', 'err');
  }
  renderDuel();
}

function reportResult(win) {
  if (!state.duel || state.duel.stage !== 'fight') return;
  state.duel.myResult = !!win;
  send({ t: 'duel.result', to: state.duel.peer, win: !!win, round: state.duel.round });
  state.score = state.score || { me: 0, them: 0 };
  log('you report: ' + (win ? 'win' : 'loss') + ' — waiting for foe confirmation…', 'me');
  settleDuelIfReady('me');
}

/* ------------------------------------------- experimental: opponent injection */
function foeSummary(card) {
  if (!card) return 'no card';
  const bits = [card.name || 'Friend'];
  if (card.level != null) bits.push('lvl ' + card.level);
  const gear = card.gear || {};
  const show = ['Weapon', 'Armor', 'Helm', 'Helmet', 'Ranged', 'Magic'].filter((k) => gear[k]).map((k) => k + '=' + gear[k]);
  if (show.length) bits.push(show.slice(0, 4).join(' '));
  return bits.join(' · ');
}
function injectOpponent() {
  const card = state.duel && state.duel.peerCard;
  if (!card) { log('no opponent card yet — duel first so we learn their build', 'err'); return; }
  const raw = readKey(C.KEYS.users);
  if (!raw) { log('no save to patch (play the game once first)', 'err'); return; }
  const preview = 'Inject "' + foeSummary(card) + '" as a bot in YOUR save?\n\nThis clones your warrior, copies their name/level/gear, restarts needed. Safe: auto-backup + Revert. Re-press replaces the old clone (never stacks).';
  try { if (!confirm(preview)) return; } catch {}
  backupSave();
  let xml;
  try { xml = C.decodeUsers(raw); } catch (e) { log('decode failed: ' + e.message, 'err'); return; }
  const inj = C.injectOpponentIntoUsers(xml, card);
  if (!inj.ok) { log('inject failed: ' + (inj.reason || 'unknown'), 'err'); return; }
  // Validate encode round-trip before writing to the live save.
  let encoded;
  try {
    encoded = C.encodeUsers(inj.xml);
    const back = C.decodeUsers(encoded);
    if (back !== inj.xml) { log('inject validation failed (round-trip mismatch) — not written', 'err'); return; }
  } catch (e) { log('inject validation failed: ' + e.message, 'err'); return; }
  if (!writeKey(C.KEYS.users, encoded)) return;
  const revBtn = $('#sl-revert');
  if (revBtn) revBtn.disabled = false;
  log('injected "' + inj.injectedName + '" (' + foeSummary(card) + ')' + (inj.removed ? ' — replaced ' + inj.removed + ' old clone(s)' : '') + '. Restart the LAN build (close it, run Play.cmd) and look for them. "Revert save" undoes this.', 'ok');
  const m = $('#sl-duel-msg');
  if (m) m.textContent = 'injected "' + inj.injectedName + '" — restart the game to fight them (Revert undoes)';
}

/* ------------------------------------------------- Phase 4a: safe introspection */
function debugClock() {
  try {
    const w = window;
    const roots = [w.J, w.SF2, w.Ka && w.Ka.SF2].filter(Boolean);
    for (const r of roots) {
      const inst = r.I || r.i || null;
      if (inst && inst.Nc) return { found: true, active: !!inst.Nc.active, time: inst.time ?? null, vk: inst.vk ? { a: 1 } : null };
    }
    return { found: false, rafTicks: (window.__SF2LAN && window.__SF2LAN.ticks) || 0 };
  } catch (e) { return { found: false, error: e.message }; }
}
function debugTestInput(kind) {
  try {
    if (kind === 'key') {
      const ev = new KeyboardEvent('keydown', { code: 'KeyK', bubbles: true, cancelable: true });
      document.dispatchEvent(ev);
      setTimeout(() => document.dispatchEvent(new KeyboardEvent('keyup', { code: 'KeyK', bubbles: true })), 120);
      return 'dispatched KeyK down/up on document (watch fighter; no-op if not in fight)';
    }
    if (kind === 'pads') {
      const pads = (navigator.getGamepads ? navigator.getGamepads() : []).length;
      return 'gamepads visible: ' + pads + ' (connect 2nd pad / virtual pad for 2P test)';
    }
    return 'use kind=key|pads';
  } catch (e) { return 'test input failed: ' + e.message; }
}

/* ---------------------------------------------------------------- bootstrap */
function boot() {
  state.score = { me: 0, them: 0 };
  state.serverOffset = 0;
  buildUI();
  log('LAN overlay ready (mod ' + VERSION + ', protocol ' + PROTO + ')', 'ok');
  log('1) one PC: "I am the host"   2) other PC: type the IP + Join', 'sys');
  const c = readCard();
  if (!c.ok) log('fighter card: ' + c.reason, 'err');
  else log('fighter card: ' + c.name + ' (level ' + c.level + ')', 'ok');
  window.__SF2LAN.lan = { state, connect, refreshCard, injectOpponent, revertSave, send, duelChallenge, duelStart, reportResult, rematch, cancelDuel, resetScore };
  window.__SF2LAN.debug = { clock: debugClock, testInput: debugTestInput, version: () => ({ mod: VERSION, proto: PROTO }) };
}
boot();




